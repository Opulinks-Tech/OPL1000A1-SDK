import csv


class Reg(object):
    _SPECIAL_FIELD = "reserved"
    def __init__(self, _addr, _name):
        self._addr = _addr
        self._name = _name
        self._bit_name_dict = {}
        self._bit_fields = []
        self._tmp_bits = []
    @property
    def name(self):
        return self._name
    
    def append_bit(self, items):
        self._tmp_bits.append(items)
    
    def parsing_bits(self):
        for bit, def_value, name in self._tmp_bits:
            if name in self._bit_name_dict:
                bitfield = self._bit_name_dict[name]
                bitfield.add_bit(bit, def_value)
            else:
                if name == self._SPECIAL_FIELD:
                    bitfield = ReservedBitfield(name, bit, def_value)
                else:
                    bitfield = BitField(name, bit, def_value)
                self._bit_name_dict[name] = bitfield
                self._bit_fields.append(bitfield)
    def compare(self, values):
        result = []
        for bit in self._bit_fields:
            bit_result = []
            for regv in values:
                bit_result.append(bit.get_bitvalue(regv))
            
            bit_result.insert(0, (len(set(bit_result)) == 1))
            bit_result.insert(0, bit.show())
            result.append(bit_result)
        return result
            
class ReservedBitfield(object):
    def __init__(self, name, bit, def_value):
        self._name = name
        self._bit_mask = 1 << bit
    def add_bit(self, bit, def_value):
        self._bit_mask |= 1 << bit
    def show(self):
        return "{name}[{bmask:08X}]".format(name=self._name, bmask=self._bit_mask)
    def get_bitvalue(self, regvalue):
        value = regvalue & self._bit_mask
        bits = bin(self._bit_mask)
        least_one_pos = bits.rfind('1')
        assert(least_one_pos > 0)
        least = len(bits) - least_one_pos - 1
        return value >> least
    
class BitField(object):
    def __init__(self, name, bit, def_value):
        self._name = name
        self._bit_s = bit
        self._bit_e = bit
        self._def_value = def_value
    def add_bit(self, bit, def_value):
        if bit > self._bit_s:
            self._def_value |= def_value << (bit - self._bit_s)
        else:
            self._def_value = (self._def_value << (self._bit_s - bit)) | def_value
            self._bit_s = bit
        
        if bit > self._bit_e:
            self._bit_e = bit
        
    def show(self):
        if self._bit_s == self._bit_e:
            return "{name}[{b}]".format(name=self._name, b=self._bit_s)
        return "{name}[{be}:{bs}]".format(name=self._name, be=self._bit_e, bs=self._bit_s)
    def get_bitvalue(self, regvalue):
        bit_mask = ((1 << (self._bit_e + 1)) - 1) ^ (( 1 << self._bit_s) - 1)
        try:
            value = regvalue & bit_mask
        except TypeError:
            pass
        return value >> self._bit_s
        

def parsing_csv(fn, regs):
    _ITEM_LEN_PER_LINE = 4
    
    with open(fn) as csvf:
        csv_reader = csv.reader(csvf)
        for row in csv_reader:
            if len(row) < _ITEM_LEN_PER_LINE:
                #print("Unknown CSV line")
                continue
            addr_s, bit_s, def_value_s, name = row[:_ITEM_LEN_PER_LINE]
            valid = True
            try:
                addr = int(addr_s, 16)
                bit = int(bit_s)
                def_value = int(def_value_s)
                if addr not in regs:
                    valid = False
                    print("Not found in regs: 0x%08X"%addr)
            except ValueError:
                valid = False
            
            if not valid:
                continue
            
            regs[addr].append_bit((bit, def_value, name))
 
def gen_reg_bits(regs):
    for reg in regs.values():
        reg.parsing_bits()
 
    

def parsing_header(addr_base, fn, regs={}):
    f = open(fn, 'r')
    for line in f:
        items = line.split()
        if len(items) < 4:
            continue
        
        name = items[1]
        offset_str = items[3]
        offset_str = offset_str.replace(";","")
        offset_item = offset_str.split('h')
        offset = offset_item.pop()
        addr = int(offset, 16)
        name = name.rstrip("_addr")
        reg = Reg(addr_base+addr, name)
        regs[addr_base+addr] = reg
    


def parsing():
    AOS_BASE = 0x40001000
    PHY_BASE = 0x40002000
    RF_BASE = 0x40009000
    
    aos_hdr = 'Reg\\aos_address.h'
    phy_hdr = 'Reg\\phy_address.h'
    rf_hdr = 'Reg\\rf_cr_address.h'
    regs = {}
    parsing_header(AOS_BASE, aos_hdr, regs)
    parsing_header(PHY_BASE, phy_hdr, regs)
    parsing_header(RF_BASE, rf_hdr, regs)
    
    aos_csv = 'Reg\\A0_AOS40001000_Plus.csv'
    phy_csv = 'Reg\\A0_PHY40002000_Plus.csv'
    rf_csv = 'Reg\\A0_RF40009000_Plus.csv'
    parsing_csv(aos_csv, regs)
    parsing_csv(phy_csv, regs)
    parsing_csv(rf_csv, regs)
    gen_reg_bits(regs)
    
    return regs

    
    