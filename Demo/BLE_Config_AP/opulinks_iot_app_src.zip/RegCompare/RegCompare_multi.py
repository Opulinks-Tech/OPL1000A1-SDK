import os

import RegAddr

_SHOW_ONLY_DIFF = True

_SRC_TYPE_JLINK_FORMAT = 0
_SRC_TYPE_OPENOCD = 1
_SRC_TYPE_4WORDS = 2


def parsing_jlink_format(lines):
    JLINK_DELEIMTER = '='
    regs = {}
    for line in lines:
        line = line.strip()
        items = line.split(JLINK_DELEIMTER)
        if len(items) == 1:
            #Skip
            continue
        if len(items) > 2:
            #Unknown
            print("Unknown jlink line:%s"%line)
            continue
        addr_pre, values_pre = items
        addr = int(addr_pre, 16)
        values_str = values_pre.split()
        for value_str in values_str:
            value = int(value_str, 16)
            regs[addr]= value
            addr += 4
    return regs

def parsing_openocd(lines):
    regs = {}
    for line in lines:
        line = line.strip()
        if not line:
            continue
        item = line.split()
        if len(item) != 2:
            #Unknown
            #print("Unknown open_ocd line:%s"%line)
            continue
        addr_str, value_str = item
        addr = int(addr_str, 16)
        value = int(value_str, 16)
        regs[addr]= value
    return regs

def parsing_4words(lines):
    WORDS_PER_LINE = 4
    regs = {}
    for line in lines:
        valid = True
        line = line.strip()
        if not line:
            continue
        if line.startswith('*'):
            continue
        addr_str, content = map(lambda s:s.strip(), line.split(':', 1))
        if not content:
            continue
        
        try:
            addr = int(addr_str, 16)
        except ValueError:
            valid = False
            
        values_str = content.split(maxsplit=WORDS_PER_LINE-1)
        try:
            values = map(lambda s:int(s, 16), values_str)
        except:
            valid = False

        if not valid:
            continue
        
        offset = 0
        for v in values:
            regs[addr + offset]= v
            offset += 4
    return regs
        
def compare_regs(regs, addr_start, addr_end, interval, regs_name=None):
    #Addr, RegA, RegB, CompareResult
    #Result: O : Same value
    #        X : Different value
    message = []
    for addr in range(addr_start, addr_end, interval):
        values = []
        for reg in regs:
            values.append(reg.get(addr, None))
        if None in values:
            result = False
        else:
            result = len(set(values))==1
            
        result_str = "O" if result else "X"
        values_str = []
        for val in values:
            if val is None:
                values_str.append("X")
            else:
                values_str.append("{:08X}      ".format(val))
        
        
        if _SHOW_ONLY_DIFF and result:
            continue

        try:
            _SHOW_REG_FMT_STR = "{reg_name:40}  {addr:08X}      {vlist}"
            message.append(_SHOW_REG_FMT_STR.format(
                    reg_name = regs_name[addr].name,
                    addr=addr, vlist="".join(values_str)))
        
            _SHOW_BIT_FMT_STR = "        {bit_name:40}    {vlist}"

            bit_message = regs_name[addr].compare(values)
            for msg in bit_message:
                bit_name, bit_result = msg[:2]
                bits_v = msg[2:]
            
                bits_v_str = []
                for bv in bits_v:
                    bits_v_str.append("{bv:12}  ".format(bv=bv))
                if not bit_result:
                    message.append(_SHOW_BIT_FMT_STR.format(
                                bit_name=bit_name, vlist="".join(bits_v_str)))
        except KeyError:
            message.append(_SHOW_REG_FMT_STR.format(
                    reg_name = "Unknown",
                    addr=addr, vlist="".join(values_str),
                    result_str = result_str))
        
        message.append("\n")
    return message
        
def parsing_file(src_type, src_lines):
    if src_type == _SRC_TYPE_JLINK_FORMAT:
        regs = parsing_jlink_format(src_lines)
    elif src_type == _SRC_TYPE_OPENOCD:
        regs = parsing_openocd(src_lines)
    elif src_type == _SRC_TYPE_4WORDS:
        regs = parsing_4words(src_lines)
    else:
        assert(0)
    return regs

def compare_files(srcs, output_fn):
    
    REGS_ITVL = [ ("AOS", 0x40001000, 0x4000119F),
                  ("RF", 0x40009000, 0x400090FF),
                  ("PHY", 0x40002000, 0x40002FFF)
                 ]
    REG_ADDR_INTERVAL = 4
    
    regs = []
    names = []
    for src_name, src_fn, src_type in srcs:
        with open(src_fn, 'r') as f:
            src_lines = f.readlines()
            reg_src = parsing_file(src_type, src_lines)
            regs.append(reg_src)
        names.append("{name:>8}      ".format(name=src_name))

    message = []
    #_SHOW_REG_FMT_STR = "{reg_name:40}  {addr:08X}      {va:8}      {vb:8}        {result_str}"
    regs_name = RegAddr.parsing()
    
    for name, addr_s, addr_e in REGS_ITVL:
        message.append("%s%s%s"%('='*20, name, '='*(20-len(name))))
        message.append("{reg_name:40}  {addr:>8}      {names}".format(
            reg_name="RegName", addr="Address",names="".join(names)))
        message.append('-'*80)
        message.extend(compare_regs(regs, addr_s, addr_e, REG_ADDR_INTERVAL, regs_name))
        message.append("\n"*3)
    
    with open(output_fn, 'w') as f:
        f.write("\n".join(message))
    print("Done")
    
    
    
    
    
def run_multi():
    ble_tx = '..\\BLE_TX\\01_ByAlex_Script\\DumpLeoSram_BLE_20180412.txt'
    ble_rx_agc = '..\\BLE_RX_AGC\\01_ByAlex_Script\\DumpSram_Alex_LE_RX_AGC_20180419.txt'
    wifi_tx = '..\\WiFi_TX\\01_ByAlex_Script\\DumpLeoSram_WiFi_TX_20180417.txt'
    wifi_rx_agc = '..\\WiFi_RX_AGC\\01_ByAlex_Script\\DumpLeoSram_20180409_1.txt'
    output_fn = "..\\Diff_4_mode.txt"
    
    compare_files(
        [
            ("BLE_RX_AGC", ble_rx_agc, _SRC_TYPE_4WORDS),
            ("BLE_TX", ble_tx, _SRC_TYPE_4WORDS),
            ("WIFI_RX_AGC", wifi_rx_agc, _SRC_TYPE_4WORDS),
            ("WIFI_TX", wifi_tx, _SRC_TYPE_4WORDS),
        ],
        output_fn)
    
if __name__ == "__main__":
    run_multi()

    