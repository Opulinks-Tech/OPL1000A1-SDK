package com.netlinkc.opl1000.netstrap;

import android.util.Log;

import com.netlinkc.opl1000.mainapplication.ViewUtils;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class LogService extends Thread
{
    private static BlockingQueue<String> logQueue = new LinkedBlockingDeque<>();

    private static LogService logService;

    public static void initial()
    {
        logService = new LogService();
        logService.start();
    }

    public static void log( final String log )
    {
        try
        {
            logQueue.put(log);
        }
        catch( InterruptedException e )
        {
            Log.e(LogService.class.getName(), e.getMessage(), e);
        }
    }

    @Override
    public void run()
    {
        try
        {
            while (true)
            {

                ViewUtils.updateLog(logQueue.take());

            }
        }
        catch (InterruptedException e)
        {
            Log.e(this.getClass().getName(), e.getMessage(), e);
        }
    }
}
