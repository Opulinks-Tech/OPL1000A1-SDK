package com.netlinkc.opl1000.mainapplication;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.netlinkc.opl1000.netstrap.ApInfo;
import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.NetstrapPacket;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;

public class ApPassWordActivitiy extends AppCompatActivity
{
    String   index;

    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.ap_password_view );

        getSupportActionBar().hide();

        String SSIDStr = getIntent().getStringExtra("SSID");
        index = getIntent().getStringExtra("index");

        TextView AddAp = (TextView) findViewById( R.id.Add );
        TextView WIFIStr = (TextView) findViewById( R.id.WIFIStr );

        WIFIStr.setText( "輸入 [" + SSIDStr + "] 的密碼");
        AddAp.setEnabled( false );

        EditText   passText = (EditText) findViewById( R.id.PasswordEdit );

        passText.addTextChangedListener(new TextWatcher()
        {
            public void afterTextChanged(Editable s) {}

            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {
            }

            public void onTextChanged(CharSequence s, int start,
                                      int before, int count)
            {
                TextView AddAp = (TextView) findViewById( R.id.Add );

                if( s.length() >= 8 )
                {
                    AddAp.setEnabled(true);
                    AddAp.setTextColor( Color.rgb(0x20,0x88,0xff ) );
                }
                else
                {
                    AddAp.setEnabled(false);
                    AddAp.setTextColor( Color.rgb(217,217,217 ) );
                }
            }
        });

        setShowKeyboard(true);
    }

    public void onClick( View v )
    {
        switch( v.getId() )
        {
            case R.id.Cancel:

                Intent     intent1 = new Intent();

                intent1.putExtra("PassWord", "" );
                intent1.putExtra("index", "-1" );

                setResult( RESULT_OK, intent1 );

                setShowKeyboard(false);
                finish();
                overridePendingTransition(0, 0 );
                break;

            case R.id.Add:

                Intent     intent = new Intent();
                EditText   passText = (EditText) findViewById( R.id.PasswordEdit );
                String     PasswordStr = passText.getText().toString();

                if( PasswordStr.length() >= 8 )
                {
                    intent.putExtra("PassWord", PasswordStr );
                    intent.putExtra("index", index);

                    setResult(RESULT_OK, intent);

                    setShowKeyboard(false);
                    finish();
                    overridePendingTransition(0, 0);
                }
                break;
        }
    }

    public void onBackPressed()
    {
        Intent   intent = new Intent();

        intent.putExtra("PassWord", "" );
        intent.putExtra("index", "-1" );

        setResult(RESULT_OK, intent);

        Intent intentb = new Intent("com.netlinkc.opl1000.ScrollView");

        MainActivity.bleService.MessageContext.sendBroadcast(intentb);

        finish();
        overridePendingTransition(0, 0);
    }

    private void setShowKeyboard(boolean isShow)
    {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if( isShow )
        {
            imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
        }
        else
        {
            imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
        }
    }
}
