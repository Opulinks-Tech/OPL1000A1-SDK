package com.netlinkc.opl1000.netstrap;

public class ApInfo {

    private String ssid;

    private byte[] bssid;

    private int authMode;

    private int rssi;

    private int connectStatus = -1;

    private boolean isConnected;

    public int ApConnectStatus;

    public ApInfo(NetstrapPacket packet) {
        this.ssid = packet.getSsid();
        this.bssid = packet.getBssid();
        this.authMode = packet.getAuthMode();
        this.rssi = packet.getRssi();
        this.ApConnectStatus = packet.ApConnectStatus;
    }

    public String getSsid() {
        return ssid;
    }

    public byte[] getBssid() {
        return bssid;
    }

    public int getAuthMode() {
        return authMode;
    }

    public int getRssi() {
        return rssi;
    }

    public int getConnectStatus() {
        return connectStatus;
    }

    public void setConnectStatus(int connectStatus) {
        this.connectStatus = connectStatus;
        if (connectStatus == 0) {
            isConnected = true;
        }
    }

    public boolean isConnected() {
        return isConnected;
    }

}
