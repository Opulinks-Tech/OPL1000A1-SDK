package com.netlinkc.opl1000.netstrap;

import android.util.Log;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

public class NetstrapPacket {

    public final static int PDU_TYPE_CMD_SCAN_REQ = 0x0000;

    public final static int PDU_TYPE_CMD_CONNECT_REQ = 0x0001;

    public final static int PDU_TYPE_CMD_READ_DEVICE_INFO_REQ = 0x0004;

    public final static int PDU_TYPE_CMD_WRITE_DEVICE_INFO_REQ = 0x0005;

    public final static int PDU_TYPE_CMD_OTA_VERSION_REQ = 0x0100;

    public final static int PDU_TYPE_CMD_OTA_UPGRADE_REQ = 0x0101;

    public final static int PDU_TYPE_CMD_OTA_RAW_DATA_REQ = 0x0102;

    public final static int PDU_TYPE_CMD_OTA_END_REQ = 0x0103;


    public final static int PDU_TYPE_EVT_SCAN_RSP = 0x1000;

    public final static int PDU_TYPE_EVT_SCAN_END = 0x1001;

    public final static int PDU_TYPE_EVT_CONNECT_RSP = 0x1002;

    public final static int PDU_TYPE_EVT_READ_DEVICE_INFO_RSP = 0x1005;

    public final static int PDU_TYPE_EVT_WRITE_DEVICE_INFO_RSP = 0x1006;

    public final static int PDU_TYPE_EVT_OTA_VERSION_RSP = 0x1100;

    public final static int PDU_TYPE_EVT_OTA_UPGRADE_RSP = 0x1101;

    public final static int PDU_TYPE_EVT_OTA_RAW_DATA_RSP = 0x1102;

    public final static int PDU_TYPE_EVT_OTA_END_RSP = 0x1103;

    public final static int PDU_TYPE_VBATT_CAL = 0x0401;

    public final static int PDU_TYPE_IO_VOL_CAL = 0x0402;

    public final static int PDU_TYPE_TEMP_CAL = 0x0403;

    public final static int PDU_TYPE_VBATT_CAL_RSP = 0x1401;

    public final static int PDU_TYPE_IO_VOL_CAL_RSP = 0x1402;

    public final static int PDU_TYPE_TEMP_CAL_RSP = 0x1403;


    public final static int SCAN_TYPE_ACTIVE = 0;

    public final static int SCAN_TYPE_PASSIVE = 1;

    public final static int AUTH_MODE_OPEN = 0;

    public final static int AUTH_MODE_WEP = 1;

    public final static int AUTH_MODE_WPA_PSK = 2;

    public final static int AUTH_MODE_WPA2_PSK = 3;

    public final static int AUTH_MODE_WPA_WPA2_PSK = 4;

    public final static int AUTH_MODE_WPA2_ENTERPRISE_PSK = 5;

    public final static int CONNECT_STATUS_SUCCESS = 0;

    public int ApConnectStatus;

    private static ByteBuffer rxBuffer;

    private static int currentLength = 0;

    /******************** header ********************/
    private int cmdId;

    private int length;

    /******************** payload of PDU_TYPE_CMD_SCAN_REQ ********************/
    private boolean showHidden;

    private int scanType;

    /******************** payload of PDU_TYPE_CMD_CONNECT_REQ ********************/
    private byte[] bssid;

    private String password;

    private int Ap_ConnectStatus;

    /******************** payload of PDU_TYPE_CMD_OTA_UPGRADE_REQ ********************/
    private int maxRxOctet;

    /******************** payload of PDU_TYPE_CMD_OTA_RAW_DATA_REQ ********************/
    private byte[] rawData;

    /******************** payload of PDU_TYPE_CMD_OTA_END_REQ ********************/
    private int reason;

    /******************** payload of PDU_TYPE_EVT_SCAN_RSP ********************/
    private String ssid;

    private int authMode;

    private int rssi;

    /******************** payload of PDU_TYPE_EVT_CONNECT_RSP ********************/
    private int connectStatus;

    /******************** payload of PDU_TYPE_EVT_CONNECT_RSP ********************/
    private byte[] deviceId;

    private String manufactureName;

    private int writeStatus;

    /******************** payload of PDU_TYPE_CMD_OTA_VERSION_RSP ********************/
    private int status;

    private long projectId;

    private long chipId;

    private long fwId;


    public int getCmdId() {
        return cmdId;
    }

    public byte[] getBssid() {
        return bssid;
    }

    public String getSsid() {
        return ssid;
    }

    public int getAuthMode() {
        return authMode;
    }

    public int getRssi() {
        return rssi;
    }

    public int getConnectStatus() {
        return connectStatus;
    }

    public int getReason() {
        return reason;
    }

    public int getStatus() {
        return status;
    }

    public long getProjectId() {
        return projectId;
    }

    public long getChipId() {
        return chipId;
    }

    public long getFwId() {
        return fwId;
    }

    public byte[] getBytes() {
        ByteBuffer buf = null;

        switch (cmdId) {
            case PDU_TYPE_VBATT_CAL:
                buf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 4)
                        .put(rawData);
                break;
            case PDU_TYPE_IO_VOL_CAL:
                buf = ByteBuffer.allocate(9).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 5)
                        .put(rawData);
                break;
            case PDU_TYPE_TEMP_CAL:
                buf = ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 4)
                        .put(rawData);
                break;

            case PDU_TYPE_CMD_SCAN_REQ:
                buf = ByteBuffer.allocate(6).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 2)
                        .put((byte) (showHidden ? 1 : 0))
                        .put((byte) scanType);
                break;

            case PDU_TYPE_CMD_CONNECT_REQ:
                buf = ByteBuffer.allocate(12 + password.length()).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) (8 + password.length()))
                        .put(bssid)
                        .put((byte) Ap_ConnectStatus)
                        .put((byte) password.length())
                        .put(password.getBytes());
                break;

            case PDU_TYPE_CMD_READ_DEVICE_INFO_REQ:
            case PDU_TYPE_CMD_OTA_VERSION_REQ:
                buf = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 0);
                break;

            case PDU_TYPE_CMD_WRITE_DEVICE_INFO_REQ:
                buf = ByteBuffer.allocate(11 + manufactureName.length()).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) (7 + manufactureName.length()))
                        .put(deviceId)
                        .put((byte) manufactureName.length())
                        .put(manufactureName.getBytes());
                break;

            case PDU_TYPE_CMD_OTA_UPGRADE_REQ:
                buf = ByteBuffer.allocate(30).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 26)
                        .putShort((short) maxRxOctet)
                        .put(rawData);
                break;

            case PDU_TYPE_CMD_OTA_RAW_DATA_REQ:
                buf = ByteBuffer.allocate(4 + rawData.length).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) rawData.length)
                        .put(rawData);
                break;

            case PDU_TYPE_CMD_OTA_END_REQ:
                buf = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN)
                        .putShort((short) cmdId)
                        .putShort((short) 1)
                        .put((byte) reason);
                break;
        }
        return buf.array();
    }

    @Override
    public String toString() {
        StringBuilder str = new StringBuilder();

        switch (cmdId) {
            case PDU_TYPE_CMD_SCAN_REQ:
                str.append("[SCAN_REQ]\n")
                        .append("showHidden: " + showHidden + "\n")
                        .append("scanType: " + (scanType == SCAN_TYPE_ACTIVE ? "ACTIVE" : "PASSIVE") + "\n");
                break;

            case PDU_TYPE_EVT_SCAN_RSP:
                str.append("[SCAN_RSP]\n")
                        .append("ssid: " + ssid + "\n")
                        .append("bssid: " + getMacAddress(bssid) + "\n")
                        .append("authMode: " + getAuthModeDescription(authMode) + "\n")
                        .append("rssi: " + rssi + "\n");
                break;

            case PDU_TYPE_EVT_SCAN_END:
                str.append("[SCAN_END]\n");
                break;

            case PDU_TYPE_CMD_CONNECT_REQ:
                str.append("[CONNECT_REQ]\n")
                        .append("bssid: " + getMacAddress(bssid) + "\n")
                        .append("password: " + password + "\n");
                break;

            case PDU_TYPE_EVT_CONNECT_RSP:
                str.append("[CONNECT_RSP]\n")
                        .append("status: " + (connectStatus == CONNECT_STATUS_SUCCESS ? "SUCCESS" : "FAIL") + "\n");
                break;

            case PDU_TYPE_CMD_READ_DEVICE_INFO_REQ:
                str.append("[READ_DEVICE_REQ]\n");
                break;

            case PDU_TYPE_EVT_READ_DEVICE_INFO_RSP:
                str.append("[READ_DEVICE_RSP]\n")
                        .append("deviceId: " + getMacAddress(deviceId) + "\n")
                        .append("manufactureName: " + manufactureName + "\n");
                break;

            case PDU_TYPE_CMD_WRITE_DEVICE_INFO_REQ:
                str.append("[WRITE_DEVICE_REQ]\n")
                        .append("deviceId: " + getMacAddress(deviceId) + "\n")
                        .append("manufactureName: " + manufactureName + "\n");
                break;

            case PDU_TYPE_EVT_WRITE_DEVICE_INFO_RSP:
                str.append("[WRITE_DEVICE_RSP]\n")
                        .append("status: " + writeStatus + "\n");
                break;

            case PDU_TYPE_CMD_OTA_VERSION_REQ:
                str.append("[OTA_VERSION_REQ]\n");
                break;

            case PDU_TYPE_EVT_OTA_VERSION_RSP:
                str.append("[OTA_VERSION_RSP]\n")
                        .append("status: " + status + "\n")
                        .append("projectId: " + String.format("0x%04X", projectId) + "\n")
                        .append("chipId: " + String.format("0x%04X", chipId) + "\n")
                        .append("fwId: " + String.format("0x%04X", fwId) + "\n");
                break;

            case PDU_TYPE_CMD_OTA_UPGRADE_REQ:
                str.append("[OTA_UPGRADE_REQ]\n")
                        .append("maxRxOctet: " + maxRxOctet + "\n");
                break;

            case PDU_TYPE_EVT_OTA_UPGRADE_RSP:
                str.append("[OTA_UPGRADE_RSP]\n")
                        .append("status: " + status + "\n");
                break;

            case PDU_TYPE_CMD_OTA_RAW_DATA_REQ:

                str.append("[OTA_RAW_DATA_REQ]\n")
                        .append("rawData.length: " + rawData.length + "\n");
                break;

            case PDU_TYPE_EVT_OTA_RAW_DATA_RSP:
                str.append("[OTA_RAW_DATA_RSP]\n");
                break;

            case PDU_TYPE_CMD_OTA_END_REQ:
                str.append("[OTA_END_REQ]\n")
                        .append("reason: " + reason + "\n");
                break;

            case PDU_TYPE_EVT_OTA_END_RSP:
                str.append("[OTA_END_RSP]\n")
                        .append("reason: " + reason + "\n");
                break;
            case PDU_TYPE_VBATT_CAL_RSP:
                str.append("[VBATT_CAL_END_RSP]\n")
                        .append("reason: " + reason + "\n");
                break;

            case PDU_TYPE_IO_VOL_CAL_RSP:
                str.append("[IO_VOL_CAL_END_RSP]\n")
                        .append("reason: " + reason + "\n");
                break;

            case PDU_TYPE_TEMP_CAL_RSP:
                str.append("[TEMP_CAL_END_RSP]\n")
                        .append("reason: " + reason + "\n");
                break;
        }

        return str.toString();
    }

    public static NetstrapPacket createcalvbattPacket(float fvbatt) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_VBATT_CAL;
        packet.rawData = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(fvbatt).array();
        return packet;
    }

    public static NetstrapPacket createcaliovolPacket(byte IOpin, float fiovol) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_IO_VOL_CAL;
        packet.rawData = new byte[5];
        packet.rawData[0] = IOpin;

        byte[] ttemp;
        ttemp = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(fiovol).array();
        packet.rawData[1] = ttemp[0];
        packet.rawData[2] = ttemp[1];
        packet.rawData[3] = ttemp[2];
        packet.rawData[4] = ttemp[3];
        return packet;
    }

    public static NetstrapPacket createcaltempPacket(float ftemp) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_TEMP_CAL;
        packet.rawData = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(ftemp).array();
        return packet;
    }

    public static NetstrapPacket createScanReqPacket(boolean showHidden, int scanType) {
        NetstrapPacket packet = new NetstrapPacket();

        packet.cmdId = PDU_TYPE_CMD_SCAN_REQ;
        packet.showHidden = showHidden;
        packet.scanType = scanType;

        return packet;
    }

    public static NetstrapPacket createConnectReqPacket(byte[] bssid, String password, int ConnectStatus) {
        NetstrapPacket packet = new NetstrapPacket();

        packet.cmdId = PDU_TYPE_CMD_CONNECT_REQ;
        packet.bssid = bssid;
        packet.password = password;
        packet.Ap_ConnectStatus = ConnectStatus;

        return packet;
    }

    public static NetstrapPacket createReadDeviceInfoReqPacket() {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_CMD_READ_DEVICE_INFO_REQ;
        return packet;
    }

    public static NetstrapPacket createWriteDeviceInfoReqPacket(byte[] deviceId, String manufactureName) {
        NetstrapPacket packet = new NetstrapPacket();

        packet.cmdId = PDU_TYPE_CMD_WRITE_DEVICE_INFO_REQ;
        packet.deviceId = deviceId;
        packet.manufactureName = manufactureName;

        return packet;
    }

    public static NetstrapPacket createOtaVersionReqPacket() {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_CMD_OTA_VERSION_REQ;
        return packet;
    }

    public static NetstrapPacket createOtaUpgradeReqPacket(int maxRxOctet, byte[] header) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_CMD_OTA_UPGRADE_REQ;
        packet.maxRxOctet = maxRxOctet;
        packet.rawData = header;
        return packet;
    }

    public static NetstrapPacket createOtaRawDataReqPacket(byte[] rawData) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_CMD_OTA_RAW_DATA_REQ;
        packet.rawData = rawData;
        return packet;
    }

    public static NetstrapPacket createOtaEndReqPacket(int reason) {
        NetstrapPacket packet = new NetstrapPacket();
        packet.cmdId = PDU_TYPE_CMD_OTA_END_REQ;
        packet.reason = reason;
        return packet;
    }

    public static synchronized List<NetstrapPacket> decodePacket(byte[] data)
    {
        StringBuilder log = new StringBuilder();
        List<NetstrapPacket> ls = new ArrayList<>();

        // full buffer
        if( rxBuffer == null )
            rxBuffer = ByteBuffer.allocate(1024).order(ByteOrder.LITTLE_ENDIAN);

        rxBuffer.put(data);
        currentLength += data.length;
        log.append("in: " + data.length + ", all: " + currentLength + ", ");

        // check whether PDU is complete
        while(true)
        {
            int allPacketLength = rxBuffer.getShort(2) + 4;
            if( currentLength >= allPacketLength )
            {
                NetstrapPacket rxPacket = new NetstrapPacket();
                rxPacket.cmdId = rxBuffer.getShort(0);

                // decode by PDU_TYPE
                switch (rxPacket.cmdId) {
                    case PDU_TYPE_EVT_SCAN_RSP:
                        decodeScanRsp(rxPacket, rxBuffer);
                        break;
                    case PDU_TYPE_EVT_SCAN_END:
                        break;
                    case PDU_TYPE_EVT_CONNECT_RSP:
                        rxPacket.connectStatus = rxBuffer.get(4);
                        break;
                    case PDU_TYPE_EVT_READ_DEVICE_INFO_RSP:
                        decodeReadDeviceInfoRsp(rxPacket, rxBuffer);
                        break;
                    case PDU_TYPE_EVT_WRITE_DEVICE_INFO_RSP:
                        rxPacket.writeStatus = rxBuffer.get(4);
                        break;
                    case PDU_TYPE_EVT_OTA_VERSION_RSP:
                        decodeOtaVersionRsp(rxPacket, rxBuffer);
                        break;
                    case PDU_TYPE_EVT_OTA_UPGRADE_RSP:
                        rxPacket.status = rxBuffer.get(4);
                        break;
                    case PDU_TYPE_EVT_OTA_END_RSP:
                        rxPacket.reason = rxBuffer.get(4);
                        break;
                }

                // reset buffer
                currentLength -= allPacketLength;
                byte[] rxBytes = new byte[1024];
                for (int i = 0; i < currentLength; i++) {
                    rxBytes[i] = rxBuffer.get(allPacketLength + i);
                }

                ByteBuffer newBuffer = ByteBuffer.allocate(1024).order(ByteOrder.LITTLE_ENDIAN);
                newBuffer.put(rxBytes, 0, currentLength);
                rxBuffer = newBuffer;

                // Log.e("aaaaaaaaaaaaaaaaaaa = " + currentLength, "<NetstrapPacket> decodePacket = " + ls.size() + " allPacketLength = " + allPacketLength );

                ls.add(rxPacket);
            }
            else
            {
                currentLength = 0;
                // Log.e("bbbbbbbbbbbbbbbbbbbbbb = " + currentLength, "<NetstrapPacket> decodePacket = " + ls.size() + " allPacketLength = " + allPacketLength );
               break;
            }
        }
        log.append("rx_pkt: " + ls.size());
        //Log.i("OPL1000", log.toString());

        return ls;
    }

    private static void decodeScanRsp(NetstrapPacket pkt, ByteBuffer buf) {
        // ssid
        int ssidLength = buf.get(4);
        byte[] ssid = new byte[ssidLength];
        for (int i = 0; i < ssidLength; i++)
            ssid[i] = buf.get(i + 5);
        pkt.ssid = new String(ssid);

        // bssid
        byte[] bssid = new byte[6];
        for (int i = 0; i < 6; i++)
            bssid[i] = buf.get(i + 5 + ssidLength);
        pkt.bssid = bssid;

        // authMode
        pkt.authMode = buf.get(11 + ssidLength);

        // rssi
        pkt.rssi = buf.get(12 + ssidLength);
    }

    private static void decodeReadDeviceInfoRsp(NetstrapPacket pkt, ByteBuffer buf) {
        int deviceIdOffset = 4;
        int deviceIdLen = 6;
        int manufactureNameLengthOffset = 10;
        int manufactureNameOffset = 11;

        // deviceId
        byte[] deviceId = new byte[deviceIdLen];
        for (int i = 0; i < deviceIdLen; i++)
            deviceId[i] = buf.get(deviceIdOffset + i);
        pkt.deviceId = deviceId;

        // manufactureName
        int manufactureNameLength = buf.get(manufactureNameLengthOffset);
        byte[] manufactureName = new byte[manufactureNameLength];
        for (int i = 0; i < manufactureNameLength; i++)
            manufactureName[i] = buf.get(manufactureNameOffset + i);
        pkt.manufactureName = new String(manufactureName);
    }

    private static void decodeOtaVersionRsp(NetstrapPacket pkt, ByteBuffer buf) {
        int statusOffset = 4;
        int projectIdOffset = 5;
        int chipIdOffset = 7;
        int fwIdOffset = 9;

        pkt.status = buf.get(statusOffset);
        pkt.projectId = buf.getInt(projectIdOffset);
        pkt.chipId = buf.getInt(chipIdOffset);
        pkt.fwId = buf.getInt(fwIdOffset);
    }

    public static String getAuthModeDescription(int authMode) {
        String description = "";

        switch (authMode) {
            case AUTH_MODE_OPEN:
                description = "OPEN";
                break;
            case AUTH_MODE_WEP:
                description = "WEP";
                break;
            case AUTH_MODE_WPA_PSK:
                description = "WPA";
                break;
            case AUTH_MODE_WPA2_PSK:
                description = "WPA2";
                break;
            case AUTH_MODE_WPA_WPA2_PSK:
                description = "WPA/WPA2";
                break;
            case AUTH_MODE_WPA2_ENTERPRISE_PSK:
                description = "WPA2-Enterprise";
                break;
        }

        return description;
    }

    public static String getMacAddress(byte[] bssid) {
        return String.format("%02X-%02X-%02X-%02X-%02X-%02X", bssid[0], bssid[1], bssid[2], bssid[3], bssid[4], bssid[5]);
    }

    static void dump(byte[] buf) {
        for (int i = 0; i < buf.length; i++) {
            System.out.printf("%02X ", buf[i]);
        }
        System.out.println("\n\n");
    }

    public static void main(String[] args) {
        NetstrapPacket otaVerReq = NetstrapPacket.createOtaVersionReqPacket();
        System.out.println(otaVerReq);
        dump(otaVerReq.getBytes());

        List<NetstrapPacket> ls = NetstrapPacket.decodePacket(new byte[] {0x00, 0x11, 0x09, 0x00, 0x00, 0x01, 0x00, 0x02, 0x00, 0x03, 0x00});
        for (NetstrapPacket pkt : ls) {
            System.out.println(pkt);
        }

        NetstrapPacket otaUpgradeReq = NetstrapPacket.createOtaUpgradeReqPacket(300, new byte[] {1,2,3,4});
        System.out.println(otaUpgradeReq);
        dump(otaUpgradeReq.getBytes());

        ls = NetstrapPacket.decodePacket(new byte[] {0x01, 0x11, 0x01, 0x00, 0x00});
        for (NetstrapPacket pkt : ls) {
            System.out.println(pkt);
        }

        NetstrapPacket otaRawDataReq = NetstrapPacket.createOtaRawDataReqPacket(new byte[] {1, 2, 3, 4, 5, 6, 7, 8, 9, 10});
        System.out.println(otaRawDataReq);
        dump(otaRawDataReq.getBytes());

        NetstrapPacket otaEndReq = NetstrapPacket.createOtaEndReqPacket(0);
        System.out.println(otaEndReq);
        dump(otaEndReq.getBytes());

        ls = NetstrapPacket.decodePacket(new byte[] {0x02, 0x11, 0x01, 0x00, 0x00});
        for (NetstrapPacket pkt : ls) {
            System.out.println(pkt);
        }
    }

}
