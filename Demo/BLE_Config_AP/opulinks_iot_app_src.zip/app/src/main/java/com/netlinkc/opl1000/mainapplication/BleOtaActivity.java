package com.netlinkc.opl1000.mainapplication;

import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.Activity;

import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.BleService;
import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.NetstrapService;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;
import com.netlinkc.opl1000.netstrap.OtaService;

import android.view.Window;
import android.view.WindowManager;

public class BleOtaActivity extends AppCompatActivity {
    private static final int FILE_SELECT_CODE = 0x1002;
    private boolean isApViewEverEntered;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_ota);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
//        getWindow().getDecorView().setBackgroundColor(Color.GRAY);


        // init otaButton
        Button otaButton1 = (Button) findViewById(R.id.choosefileBtn);
        otaButton1.setEnabled(true);
        otaButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showFileChooser();
            }
        });



        // init logText
       TextView logText = (TextView) findViewById(R.id.logText1);
       ViewUtils.setLogText(logText);

        // init logService
        LogService.initial();

    }
/*
    private void calvbattproc()
    {
        final String strVoltage = txtVolCal.getText().toString();
        NetstrapTask     task = new NetstrapTask( NetstrapState.TO_CAL_VBATT );
        float voltage = Float.parseFloat(strVoltage);
        task.setData("Voltage", voltage);
        BeanFactory.getNetstrapService().addTask(task);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    private void calIOVolproc()
    {
        final String strIOVoltage = txtIOVolCal.getText().toString();
        final String strPIN = txtPin.getText().toString();
        NetstrapTask task = new NetstrapTask( NetstrapState.TO_CAL_IO_VOL );
        float voltage = Float.parseFloat(strIOVoltage);
        byte Pin = Byte.parseByte(strPIN);
        task.setData("IOVoltage", voltage);
        task.setData("IOPIN", Pin);
        BeanFactory.getNetstrapService().addTask(task);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }

    private void calTempproc()
    {
        final String strTemp = txtTempCal.getText().toString();
        NetstrapTask     task = new NetstrapTask( NetstrapState.TO_CAL_TEMP );
        float temperture = Float.parseFloat(strTemp);
        task.setData("Temperture", temperture);
        BeanFactory.getNetstrapService().addTask(task);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
    }
*/
    private void showFileChooser()
    {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try
        {
            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), FILE_SELECT_CODE);
        }
        catch( android.content.ActivityNotFoundException ex )
        {
            Toast.makeText(this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
        }
    }

    void startApListActivity()
    {
        Intent intent = new Intent(BleOtaActivity.this, ApListActivitiy.class);
        intent.putExtra("isApViewEverEntered", isApViewEverEntered);
        isApViewEverEntered = true;
        startActivity(intent);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch(requestCode)
        {
 /*           case REQUEST_ENABLE_BLE:
                if( resultCode == RESULT_OK )
                {
                    LogService.log("Enabling ble request is successful.");
                    startNetstrapService();
                }
                else
                {
                    LogService.log("Please permit enabling ble request.");
                }
                break;
  */
            case FILE_SELECT_CODE:

                if( resultCode == RESULT_OK )
                {
                    Uri uri = data.getData();
                    String path = uri.getPath();
                    Log.i("OPL1000", path);
                    BeanFactory.getOtaService().setOtaImagePath(uri);
                    BeanFactory.getNetstrapService().addTask(new NetstrapTask(NetstrapState.OTA_START));
                }
                else
                {
                    LogService.log("Please choose correct OTA image.");
                }
                break;
        }
    }

    @Override
    public void onBackPressed()
    {
        BeanFactory.getNetstrapService().getBleService().disconnect();
        Intent intent = new Intent(BleOtaActivity.this, MainActivity.class);
        startActivityForResult(intent,0);
        finish();

        overridePendingTransition(0, 0);
    }
}
