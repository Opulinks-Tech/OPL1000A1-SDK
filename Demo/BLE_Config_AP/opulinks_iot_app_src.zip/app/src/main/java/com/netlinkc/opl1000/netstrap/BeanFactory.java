package com.netlinkc.opl1000.netstrap;

public class BeanFactory {

    private static NetstrapService netstrapService;

    private static OtaService otaService;

    public static NetstrapService getNetstrapService() {
        return netstrapService;
    }

    public static void setNetstrapService(NetstrapService netstrapService) {
        BeanFactory.netstrapService = netstrapService;
    }

    public static OtaService getOtaService() {
        return otaService;
    }

    public static void setOtaService(OtaService otaService) {
        BeanFactory.otaService = otaService;
    }
}
