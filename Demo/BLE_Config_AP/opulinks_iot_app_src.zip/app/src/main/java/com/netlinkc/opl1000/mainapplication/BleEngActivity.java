package com.netlinkc.opl1000.mainapplication;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.netlinkc.opl1000.netstrap.LogService;

public class BleEngActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_eng);
    }


    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.BleOtaButton:
                Intent intent1 = new Intent(BleEngActivity.this, BleOtaActivity.class );
                startActivityForResult( intent1, 0 );
                break;

            case R.id.BleCalButton:

                Intent intent2 = new Intent(BleEngActivity.this, bleCalActivity.class );
                startActivityForResult( intent2, 0 );
                break;


        }
    }
}
