package com.netlinkc.opl1000.mainapplication;

import android.content.Intent;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.BleService;
import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.NetstrapService;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;
import com.netlinkc.opl1000.netstrap.OtaService;

public class bleCalActivity extends AppCompatActivity {

    private boolean isApViewEverEntered;
    EditText txtVolCal;
    EditText txtIOVolCal;
    EditText txtTempCal;
    EditText txtPin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ble_cal);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
//        getWindow().getDecorView().setBackgroundColor(Color.GRAY);


        txtVolCal =(EditText) findViewById(R.id.txtVolCal);
        txtIOVolCal =(EditText) findViewById(R.id.txtIOVolCal);
        txtTempCal =(EditText) findViewById(R.id.txtTempCal);
        txtPin =(EditText) findViewById(R.id.txtPin);




        Button VolCalButton = (Button) findViewById(R.id.btnVolCal);
        VolCalButton.setEnabled(true);
        VolCalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calvbattproc();
            }
        });
        Button IOVolCalButton = (Button) findViewById(R.id.btnIOVolCal);
        IOVolCalButton.setEnabled(true);
        IOVolCalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calIOVolproc();
            }
        });

        Button TempCalButton = (Button) findViewById(R.id.btnTempCal);
        TempCalButton.setEnabled(true);
        TempCalButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calTempproc();
            }
        });



        // init logText
        TextView logText = (TextView) findViewById(R.id.logText2);
        ViewUtils.setLogText(logText);

        // init logService
        LogService.initial();





    }


    private void calvbattproc()
    {
        final String strVoltage = txtVolCal.getText().toString();
        NetstrapTask     task = new NetstrapTask( NetstrapState.TO_CAL_VBATT );
        float voltage = Float.parseFloat(strVoltage);
        task.setData("Voltage", voltage);
        BeanFactory.getNetstrapService().addTask(task);

    }

    private void calIOVolproc()
    {
        final String strIOVoltage = txtIOVolCal.getText().toString();
        final String strPIN = txtPin.getText().toString();
        NetstrapTask task = new NetstrapTask( NetstrapState.TO_CAL_IO_VOL );
        float voltage = Float.parseFloat(strIOVoltage);
        byte Pin = Byte.parseByte(strPIN);
        task.setData("IOVoltage", voltage);
        task.setData("IOPIN", Pin);
        BeanFactory.getNetstrapService().addTask(task);

    }

    private void calTempproc()
    {
        final String strTemp = txtTempCal.getText().toString();
        NetstrapTask     task = new NetstrapTask( NetstrapState.TO_CAL_TEMP );
        float temperture = Float.parseFloat(strTemp);
        task.setData("Temperture", temperture);
        BeanFactory.getNetstrapService().addTask(task);

    }

    void startApListActivity()
    {
        Intent intent = new Intent(bleCalActivity.this, ApListActivitiy.class);
        intent.putExtra("isApViewEverEntered", isApViewEverEntered);
        isApViewEverEntered = true;
        startActivity(intent);
    }
}
