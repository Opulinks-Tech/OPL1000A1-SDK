package com.netlinkc.opl1000.mainapplication;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.app.AlertDialog.Builder;
import android.support.v7.app.AlertDialog;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.annotation.NonNull;
import android.util.Log;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.BleService;
import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.NetstrapService;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;
import com.netlinkc.opl1000.netstrap.OtaService;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;


public class MainActivity extends AppCompatActivity
{
    private boolean            isApViewEverEntered;
    static public String       CurrentBLE = "", CurrentBLEMac = "";
    static public BleService   bleService;
    static public boolean      ScanApList, WIFIReset, ScanApStatus, ConnectApAction;


    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.activity_main );


        ConnectApAction = false;
        ScanApStatus = false;
        WIFIReset = false;
        ScanApList = false;
        AutoPermission();

        Animation temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        TextView textView1 = (TextView)findViewById( R.id.textview1 );
        temp.setStartOffset(100);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview2 );
        temp.setStartOffset(200);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview3 );
        temp.setStartOffset(300);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview4 );
        temp.setStartOffset(400);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview5 );
        temp.setStartOffset(500);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview6 );
        temp.setStartOffset(600);
        textView1.startAnimation(temp);

        temp = (Animation) AnimationUtils.loadAnimation(this, R.anim.translate);
        textView1 = (TextView)findViewById( R.id.textview7 );
        temp.setStartOffset(700);
        textView1.startAnimation(temp);

        MainActivity.bleService = new BleService(this);
    }


    protected void onActivityResult( int requestCode, int resultCode, Intent data )
    {

    }


    private void AutoPermission()
    {
       if( !RequestLocation() )
           return;
    }

    private boolean RequestLocation()
    {
       if( Build.VERSION.SDK_INT < Build.VERSION_CODES.M )
           return true;

        if( getApplicationContext().checkSelfPermission(ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED )
            return true;

        if( ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this, ACCESS_COARSE_LOCATION ) )
        {
            AlertDialog.Builder   dialog = new AlertDialog.Builder(this);

            dialog.setTitle( "opl1000" );
            dialog.setMessage( "Request permission" );
            dialog.setIcon( android.R.drawable.ic_dialog_info );
            dialog.setCancelable( false );
            dialog.setPositiveButton( "OK", new DialogInterface.OnClickListener()
            {
                public void onClick( DialogInterface dialog, int which )
                {
                    ActivityCompat.requestPermissions( MainActivity.this, new String[]{ ACCESS_COARSE_LOCATION }, 101 );
                }
            });
            dialog.show();
        }
        else
        {
           ActivityCompat.requestPermissions( MainActivity.this, new String[]{ ACCESS_COARSE_LOCATION }, 101 );
        }
        return false;
    }

    public void onClick(View v)
    {
        switch (v.getId())
        {
            case R.id.BLEButton:

                Intent intent1 = new Intent(MainActivity.this, BLEActivity.class );

                startActivityForResult( intent1, 0 );
                break;

            case R.id.WifiButton:

                if( !ScanApList || MainActivity.bleService.bleGattClient == null )
                {
                    AlertDialog.Builder   dialog = new AlertDialog.Builder(this);

                    dialog.setTitle( "Warning window" );
                    dialog.setMessage( "Connect BLE First !" );
                    dialog.setIcon( android.R.drawable.ic_dialog_alert );
                    dialog.setCancelable( false );
                    dialog.setPositiveButton( "OK", new DialogInterface.OnClickListener()
                    {
                        public void onClick( DialogInterface dialog, int which )
                        {
                        }
                    });
                    dialog.show();
                }
                else
                {
                   Intent intent = new Intent(MainActivity.this, ApListActivitiy.class );

                   intent.putExtra("isApViewEverEntered", isApViewEverEntered );
                   isApViewEverEntered = true;
                   startActivity( intent );
                }

                break;

        }
    }

    protected void onDestroy()
    {
        super.onDestroy();

        if( MainActivity.bleService != null )
            MainActivity.bleService.close();

        if( MainActivity.bleService.bleGattClient != null )
            MainActivity.bleService.bleGattClient.close();

        if( BeanFactory.getNetstrapService() != null )
            BeanFactory.getNetstrapService().end();
    }
}
