package com.netlinkc.opl1000.mainapplication;

import android.content.Context;
import android.content.Intent;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Interpolator;
import android.view.animation.TranslateAnimation;
import android.widget.ScrollView;

public class SpringScrollView extends ScrollView
{
    private int previousY = 0;
    private int startY = 0;
    private int currentY = 0;
    private int deltaY = 0;
    private View childView;
    private Rect topRect = new Rect();
    private float moveHeight;
    private Context context;
    private boolean SearchAp = true;

    public SpringScrollView(Context context)
    {
        super(context);
    }

    public SpringScrollView(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public SpringScrollView(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    public void setParent(Context context)
    {
        this.context = context;
    }

    protected void onFinishInflate()
    {
        if( getChildCount() > 0 )
            childView = getChildAt(0);
    }

    public boolean dispatchTouchEvent( MotionEvent event )
    {
        if( childView == null )
            return super.dispatchTouchEvent(event);

        switch( event.getAction() )
        {
            case MotionEvent.ACTION_DOWN:

                startY = (int) event.getY();
                previousY = startY;
                topRect.set(childView.getLeft(), childView.getTop(), childView.getRight(), childView.getBottom());
                moveHeight = 0;
                SearchAp = true;
                break;
            case MotionEvent.ACTION_MOVE:

                currentY = (int) event.getY();
                deltaY = currentY - previousY;
                previousY = currentY;

                if( (!childView.canScrollVertically(-1) && (currentY - startY) > 0) || (!childView.canScrollVertically(1) && (currentY - startY) < 0) )
                {
                    float distance = currentY - startY;

                    if( distance < 0 )
                        distance *= -1;

                    float damping = 0.5f;//阻尼值

                    float height = getHeight();

                    if( height != 0 )
                    {
                        if( distance > height )
                            damping = 0;
                        else
                           damping = (height - distance) / height;
                    }

                    if( currentY - startY < 0 )
                        damping = 1 - damping;

                    damping *= 0.25;
                    damping += 0.25;

                    moveHeight = moveHeight + (deltaY * damping);
                    childView.layout( topRect.left, (int) (topRect.top + moveHeight), topRect.right, (int) (topRect.bottom + moveHeight) );

                    if( moveHeight < 0 )
                        SearchAp = false;
                }

                break;
            case MotionEvent.ACTION_UP:

                if( !topRect.isEmpty() )
                {
                    upDownMoveAnimation();
                    childView.layout( topRect.left, topRect.top, topRect.right, topRect.bottom );

                    Log.e("moveHeight = " + moveHeight, "topRect.bottom = " + topRect.bottom );

                    if( !MainActivity.ConnectApAction )
                    {
                        if( SearchAp && moveHeight > topRect.bottom / 7 )
                        {
                            Intent intent = new Intent("com.netlinkc.opl1000.ReScanAP");

                            MainActivity.bleService.MessageContext.sendBroadcast(intent);
                        }
                    }
                }

                startY = 0;
                currentY = 0;
                topRect.setEmpty();
                break;
        }

        return super.dispatchTouchEvent(event);
    }

    private void upDownMoveAnimation()
    {
        TranslateAnimation   animation = new TranslateAnimation( 0.0f, 0.0f, childView.getTop(), topRect.top );

        animation.setDuration( 600 );
        animation.setFillAfter( true );
        animation.setInterpolator( new DampInterpolator() );

        childView.setAnimation( animation );
    }

    public class DampInterpolator implements Interpolator
    {
       public float getInterpolation( float input )
       {
          return 1 - (1 - input) * (1 - input) * (1 - input) * (1 - input) * (1 - input);
       }
    }
}