package com.netlinkc.opl1000.mainapplication;

import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SimpleAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.netlinkc.opl1000.netstrap.ApInfo;
import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.NetstrapPacket;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;

public class ApListActivitiy extends AppCompatActivity
{
    private int              SelectAPIndex;
    private ApListAdapter    apListAdapter;
    private ListView         apListView;
    private ProgressDialog   ProgDialog;
    private ScrollView       mScrollView;
    private String           BeforeConnectItem = "", BeforeBssid = "", IPAddr = "", MaskAddr = "", GatewayAddr = "";

    protected void onCreate( Bundle savedInstanceState )
    {
        super.onCreate( savedInstanceState );
        setContentView( R.layout.ap_list_view );


        mScrollView = (ScrollView) findViewById(R.id.scrollView);
        MainActivity.bleService.MessageContext = ApListActivitiy.this;
        IntentFilter FunctionFilter = new IntentFilter();

        FunctionFilter.addAction( "com.netlinkc.opl1000.WIFIReset" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ReScanAP" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ScanAPEnd" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ConnectedItem" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ConnectedApStatus" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.DisConnectedAp" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ScrollView" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.InfoData" );
        FunctionFilter.addAction( "com.netlinkc.opl1000.ApIPAddress" );
        registerReceiver( MenuAction, FunctionFilter );

        getSupportActionBar().hide();

        ViewUtils.setApListActivity(this);   // init apListActivity

        RelativeLayout Title2 = (RelativeLayout ) findViewById( R.id.Title2 );
        Title2.setVisibility( View.GONE );

        ViewUtils.setApStatusText((TextView) findViewById( R.id.apStatusText ));   // init apStatusText

        Button readWriteButton = (Button) findViewById( R.id.readWriteButton );   // init readWriteButton
        readWriteButton.setOnClickListener( new View.OnClickListener()
        {
            public void onClick( View view )
            {
                NetstrapTask task = new NetstrapTask( NetstrapState.TO_READ_DEVICE_INFO );
                BeanFactory.getNetstrapService().addTask( task );
            }
        });

        // init apScanButton
        Button apScanButton = (Button) findViewById( R.id.apScanButton );
        apScanButton.setOnClickListener( new View.OnClickListener()
        {
            public void onClick( View view )
            {
                startToScanAp();
            }
        });
        ViewUtils.setApScanButton( apScanButton );

        Button ipbut =  (Button) findViewById( R.id.activity_setServe_switch_open );

        ipbut.setOnClickListener( new View.OnClickListener()
        {
           public void onClick( View view )
           {
              byte[]    data = {0x07, 0x00, 0x00, 0x00 };
              Handler   mHandler = new Handler();


              MainActivity.WIFIReset = true;
              MainActivity.bleService.send( data );

              mHandler.postDelayed( new Runnable()
              {
                 public void run()
                 {
                     if( MainActivity.WIFIReset )
                     {
                         MainActivity.WIFIReset = false;
                         ShowAlertDialog("Device No Response", "Message window");
                     }
                 }
              }, 5000 );
           }
        });

        // init apListView and apListAdapter
        apListView = (ListView) findViewById( R.id.apList );

        apListAdapter = new ApListAdapter(this );
        apListView.setAdapter( apListAdapter );
        apListView.setOnItemClickListener( new AdapterView.OnItemClickListener()
        {
            public void onItemClick( AdapterView<?> adapterView, View view, int i, long l )
            {
                Log.e("onActivityResult ==> " + MainActivity.ScanApList, "ScanApList = " + MainActivity.ScanApList );
                if( MainActivity.ScanApList )
                {
                    ApInfo ap = (ApInfo) apListAdapter.getItem(i);


                    SelectAPIndex = i;
                    if( ap.ApConnectStatus == 0 && !NetstrapPacket.getAuthModeDescription(ap.getAuthMode()).equals("OPEN") )
                    {
                        Intent intent = new Intent(ApListActivitiy.this, ApPassWordActivitiy.class);

                        intent.putExtra("SSID", ap.getSsid());
                        intent.putExtra("index", String.valueOf(i));
                        startActivityForResult(intent, 0);
                        Log.e("onItemClick ==>", "if" );
                    }
                    else
                    {
                        NetstrapTask     task = new NetstrapTask(NetstrapState.TO_INDICATE_DEVICE_CONNECT_AP);
                        ProgressBar      Appb = (ProgressBar) findViewById( R.id.APLoading );
                        ImageButton      Select = (ImageButton) findViewById( R.id.Select );
                        RelativeLayout   Title2 = (RelativeLayout ) findViewById( R.id.Title2 );
                        TextView         SelectTitle = (TextView) findViewById( R.id.SelectItemStr );
                        TextView         bssid = (TextView) findViewById( R.id.bssid );
                        Button           ResetBut = (Button) findViewById( R.id.activity_setServe_switch_open );


                        GatewayAddr = MaskAddr = IPAddr = "";
                        ResetBut.setEnabled(false);
                        Select.setVisibility( View.GONE );
                        Appb.setVisibility( ProgressBar.VISIBLE );
                        MainActivity.ConnectApAction = true;

                        task.setData("apInfo", ap);
                        task.setData("password", "");

                        if( ap.ApConnectStatus == 0 )
                            task.setData("ConnectStatus", 0);
                        else
                           task.setData("ConnectStatus", 1);

                        BeanFactory.getNetstrapService().addTask(task);

                        Title2.setVisibility( View.VISIBLE );
                        SelectTitle.setText( ap.getSsid() );
                        bssid.setText( NetstrapPacket.getMacAddress( ap.getBssid() ) );
                        Log.e("onItemClick ==>", "else " + NetstrapPacket.getMacAddress( ap.getBssid() ) );

                        ScrollView();
                    }
                }
                else
                   ShowAlertDialog( "Connect BLE First !", "Warning window" );
            }
        });
        ViewUtils.setApListAdapter( apListAdapter );

        if (!getIntent().getBooleanExtra("isApViewEverEntered", false) && ViewUtils.isAutoScanEnabled)
        {
            ViewUtils.setApControlButtonEnabled(true);
            apScanButton.setEnabled(false);
            startToScanAp();
        }

        ScanAP( 300 );

        ImageButton inforButton = (ImageButton) findViewById( R.id.infor );   // init readWriteButton
        inforButton.setOnClickListener( new View.OnClickListener()
        {
            public void onClick( View view )
            {
                TextView   bssid = (TextView) findViewById( R.id.bssid );

                Log.e("ssssssssssssssssss", "\nBssid : " + bssid.getText().toString() );
                ShowAlertDialog("\nIPAddr : " + IPAddr + "\nMaskAddr : " + MaskAddr + "\nGatewayAddr : " + GatewayAddr, "Message window");
            }
        });
    }

    void ScanAP( int time )
    {
       Handler mHandler = new Handler();

       mHandler.postDelayed( new Runnable()
       {
          public void run()
          {
              if( MainActivity.ScanApList )
              {
                  ProgDialog = new ProgressDialog(ApListActivitiy.this);
                  ProgDialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
                  ProgDialog.setIndeterminate(true);
                  ProgDialog.setCancelable(true);
                  ProgDialog.show();
                  ProgDialog.setContentView(R.layout.progress_dlg);
              }

              startToScanAp();
          }
       }, time );
    }

    private BroadcastReceiver MenuAction = new BroadcastReceiver()
    {
        public void onReceive(Context context, Intent intent)
        {
            if( intent.getAction().equals( "com.netlinkc.opl1000.WIFIReset" ) )
            {
                ShowAlertDialog("WIFI info has been reset", "1");
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ReScanAP" ) )
            {
                     apListAdapter.clearData();
                     apListAdapter.notifyDataSetChanged();
                     ScanAP(100 );
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ScanAPEnd" ) )
            {
                     MainActivity.ScanApStatus = false;
                     if( ProgDialog != null )
                         ProgDialog.dismiss();

                     // Log.e("xxxxxxxxxxxxxxx = " + BeforeConnectItem.isEmpty(), "BeforeConnectItem = " + BeforeConnectItem.length());
                     if( !BeforeConnectItem.isEmpty() || BeforeConnectItem.length() > 0 )
                     {
                         RelativeLayout   Title2 = (RelativeLayout) findViewById( R.id.Title2 );
                         TextView         SelectTitle = (TextView) findViewById( R.id.SelectItemStr );
                         TextView         bssid = (TextView) findViewById( R.id.bssid );
                         ImageButton      Select = (ImageButton) findViewById( R.id.Select );


                         Select.setVisibility( View.VISIBLE );
                         Title2.setVisibility( View.VISIBLE );
                         SelectTitle.setText( BeforeConnectItem );
                         bssid.setText( BeforeBssid );
                     }
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ConnectedItem" ) )
            {
                     BeforeConnectItem = intent.getStringExtra("ssid");
                     BeforeBssid = intent.getStringExtra("bssid");
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ScrollView" ) )
            {
                      ScrollView();
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.InfoData" ) )
            {
                     String   bssid = intent.getStringExtra( "bssid" );

                     ShowAlertDialog("\nBssid : " + bssid, "Message window");
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.DisConnectedAp" ) )
            {
                     if( MainActivity.bleService.bleGattClient != null )
                         MainActivity.bleService.bleGattClient.close();

                     ShowAlertDialog( "OPL1000 device disconnected !", "Warning window" );
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ApIPAddress") )
            {
                     IPAddr = intent.getStringExtra( "IPAddr" );
                     MaskAddr = intent.getStringExtra( "MaskAddr" );
                     GatewayAddr = intent.getStringExtra( "GatewayAddr" );
            }
            else if( intent.getAction().equals( "com.netlinkc.opl1000.ConnectedApStatus") )
            {
                     String        Status = intent.getStringExtra( "ConnectApStatus" );
                     String        ShowMessage = intent.getStringExtra( "ShowMessage" );
                     ProgressBar   Appb = (ProgressBar) findViewById( R.id.APLoading );
                     Button        ResetBut = (Button) findViewById( R.id.activity_setServe_switch_open );


                     ResetBut.setEnabled(true);
                     Appb.setVisibility( ProgressBar.INVISIBLE );
                     Appb.setVisibility( View.GONE );
                     if( Status.equals( "1" ) )
                     {
                         ImageButton   Select = (ImageButton) findViewById( R.id.Select );

                         Select.setVisibility( View.VISIBLE );
                         Log.e("dddddddddddddddddddd", "SelectAPIndex = " + SelectAPIndex );
                         if( SelectAPIndex < apListAdapter.getCount() )
                             apListAdapter.DeleteData(SelectAPIndex);
                     }
                     else
                     {
                        RelativeLayout   Title2 = (RelativeLayout ) findViewById( R.id.Title2 );

                        Title2.setVisibility( View.GONE );

                        if( ShowMessage.equals( "1" ) )
                            ShowAlertDialog( "Connection failed !", "Warning Message" );
                     }

                     // Log.e("dddddddddddddddddddd", "Status = " + Status );
            }
        }
    };

    private void ShowAlertDialog(String SMessage, String STitel)
    {
        final boolean         ChkWIFIReset = STitel.equals("1") ? true:false;
        AlertDialog.Builder   alertdialog = new AlertDialog.Builder(ApListActivitiy.this);

        if( STitel.equals("1") )
            alertdialog.setTitle( "Message window" );
        else
           alertdialog.setTitle(STitel);

        alertdialog.setMessage(SMessage);

        DialogInterface.OnClickListener OkClick = new DialogInterface.OnClickListener()
        {
            public void onClick(DialogInterface dialog, int which)
            {
                if( !MainActivity.ScanApList )
                    finish();

                if( ChkWIFIReset )
                    ScanAP( 100 );
            }
        };

        alertdialog.setNegativeButton("OK", OkClick );
        alertdialog.show();
    }

    protected void onDestroy()
    {
        super.onDestroy();

        unregisterReceiver(MenuAction);

        MainActivity.ScanApStatus = false;
        apListAdapter.clearData();
    }

    protected void onActivityResult( int requestCode, int resultCode, Intent data )
    {
        if( requestCode == 0 )
        {
            String PassWordStr = data.getStringExtra("PassWord");
            String index = data.getStringExtra("index");
            int ConnectStatus = data.getIntExtra("ConnectStatus", 0);

            if( index.equals("-1") )
                return;

            if( resultCode == RESULT_OK && PassWordStr != null )
            {
                int              ItemIndex = Integer.valueOf(index);
                ApInfo           apinfo = (ApInfo) apListAdapter.getItem( ItemIndex );
                NetstrapTask     task = new NetstrapTask( NetstrapState.TO_INDICATE_DEVICE_CONNECT_AP );
                RelativeLayout   Title2 = (RelativeLayout ) findViewById( R.id.Title2 );
                TextView         SelectTitle = (TextView) findViewById( R.id.SelectItemStr );
                TextView         bssid = (TextView) findViewById( R.id.bssid );
                ProgressBar      Appb = (ProgressBar) findViewById( R.id.APLoading );
                ImageButton      Select = (ImageButton) findViewById( R.id.Select );
                Button           ResetBut = (Button) findViewById( R.id.activity_setServe_switch_open );


                GatewayAddr = MaskAddr = IPAddr = "";
                ResetBut.setEnabled(false);
                Select.setVisibility( View.GONE );
                Appb.setVisibility( ProgressBar.VISIBLE );
                MainActivity.ConnectApAction = true;
                task.setData("apInfo", apinfo );
                task.setData("password", PassWordStr );
                task.setData("ConnectStatus", ConnectStatus );
                BeanFactory.getNetstrapService().addTask( task );

                Title2.setVisibility( View.VISIBLE );
                SelectTitle.setText( apinfo.getSsid() );
                bssid.setText( apinfo.getBssid().toString() );
            }

            ScrollView();
        }
    }

    private void ScrollView()
    {
        Handler mHandler = new Handler();
        mHandler.postDelayed( new Runnable()
        {
            public void run()
            {
                mScrollView.scrollTo(0,0);
            }
        }, 800 );
    }

    private void startToScanAp()
    {
        if( MainActivity.ScanApList )
        {
            BeforeConnectItem = "";
            MainActivity.ScanApStatus = true;

            NetstrapTask     task = new NetstrapTask( NetstrapState.TO_INDICATE_DEVICE_SCAN_AP );
            RelativeLayout   Title2 = (RelativeLayout ) findViewById( R.id.Title2 );


            Title2.setVisibility( View.GONE );
            task.setData("isShowHidden", true);
            task.setData("scanType", NetstrapPacket.SCAN_TYPE_PASSIVE);

            BeanFactory.getNetstrapService().addTask( task );
        }
        else
        {
           ShowAlertDialog( "Connect BLE First !", "Warning window" );
        }
    }
}
