package com.netlinkc.opl1000.mainapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;
import com.netlinkc.opl1000.netstrap.ApInfo;
import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.NetstrapPacket;

import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;

public class ApListAdapter extends BaseAdapter
{
    private LayoutInflater inflater;

    public ApListAdapter(Context context) {
        inflater = LayoutInflater.from(context);
    }

    @Override
    public int getCount() {
        return BeanFactory.getNetstrapService().getApList().size();
    }

    @Override
    public Object getItem(int i) {
        return BeanFactory.getNetstrapService().getApList().get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    public void clearData()
    {
        BeanFactory.getNetstrapService().getApList().clear();
    }

    public void DeleteData( int index )
    {
        if( index < getCount() )
        {
            BeanFactory.getNetstrapService().getApList().remove(index);
            notifyDataSetChanged();
        }
    }

    @Override
    public View getView( int i, View view, ViewGroup viewGroup )
    {
        if( view == null )
            view = inflater.inflate(R.layout.ap_list_item, viewGroup, false);

        final ApInfo ap = BeanFactory.getNetstrapService().getApList().get(i);
        ((TextView) view.findViewById(R.id.ssidText)).setText( ap.getSsid() );

        if( NetstrapPacket.getAuthModeDescription(ap.getAuthMode()).equals("OPEN") )
            ((ImageView) view.findViewById(R.id.lock)).setVisibility( View.INVISIBLE );
        else
           ((ImageView) view.findViewById(R.id.lock)).setVisibility( View.VISIBLE );

        ImageButton connect = (ImageButton) view.findViewById(R.id.infobut);

        connect.setOnClickListener(new OnClickListener()
        {
            public void onClick(View arg0)
            {
                Intent intent = new Intent( "com.netlinkc.opl1000.InfoData" );

                intent.putExtra("bssid", NetstrapPacket.getMacAddress( ap.getBssid() ) );
                MainActivity.bleService.MessageContext.sendBroadcast( intent );
            }
        });

        return view;
    }
}
