package com.netlinkc.opl1000.mainapplication;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class ViewUtils
{
    /******************** debug related parameters ********************/
    static boolean isAutoScanEnabled = false;
    static boolean isRescanEnabled = false;
    static int rescanCount = 0;

    /******************** apListActivity ********************/
    private static BLEActivity mainActivity;

    private static Button otaButton;

    private static Button apControlButton;

    private static TextView logText;

    private static Handler logHandler;

    /******************** apListActivity ********************/
    private static ApListActivitiy apListActivity;

    private static TextView apStatusText;

    private static Button apScanButton;

    private static ApListAdapter apListAdapter;

    public static void setMainActivity( BLEActivity mainActivity )
    {
        ViewUtils.mainActivity = mainActivity;
    }

    public static BLEActivity getMainActivity() {
        return mainActivity;
    }

    public static void setOtaButton(Button otaButton) {
        ViewUtils.otaButton = otaButton;
    }

    public static void setOtaButtonEnabled(final boolean isEnable)
    {
        mainActivity.runOnUiThread( new Runnable()
        {
            public void run()
            {
                otaButton.setEnabled(isEnable);
            }
        });
    }

    public static void setApControlButton( Button apControlButton )
    {
        ViewUtils.apControlButton = apControlButton;
    }

    public static void setApControlButtonEnabled( final boolean isEnable)
    {
        mainActivity.runOnUiThread( new Runnable()
        {
            public void run()
            {
                apControlButton.setEnabled(isEnable);
            }
        });
    }

    public static void setLogText( TextView logText )
    {
        ViewUtils.logText = logText;
        logHandler = new Handler( Looper.getMainLooper() );
    }

    public static void logAppendNumberSign( final String sign )
    {
        logHandler.post( new Runnable()
        {
            public void run()
            {
                logText.append(sign);
                ((ScrollView) logText.getParent()).fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    public static void updateLog( final String log )
    {
        logHandler.post( new Runnable()
        {
            public void run()
            {
                logText.append(log + "\n");
                ((ScrollView) logText.getParent()).fullScroll(View.FOCUS_DOWN);
            }
        });
    }

    public static void startApListActivity()
    {
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable()
        {
            public void run()
            {
                mainActivity.startApListActivity();
            }
        }, 2000);
    }

    public static void setApListActivity( ApListActivitiy apListActivity)
    {
        ViewUtils.apListActivity = apListActivity;
    }

    public static void setApStatusText( TextView apStatusText )
    {
        ViewUtils.apStatusText = apStatusText;
    }

    public static void updateApStatus( final String statusText )
    {
        apListActivity.runOnUiThread( new Runnable()
        {
            public void run()
            {
                String   TmpStr = null;

                if( statusText.indexOf( "connecting failed" ) != -1 )
                    TmpStr = "Connection failed !";
                else if( statusText.indexOf( "is connected" ) != -1 )
                         TmpStr = "Successful connection !";

                if( TmpStr != null )
                {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(apListActivity);

                    dialog.setTitle("Warning message");
                    dialog.setMessage(TmpStr);
                    dialog.setIcon(android.R.drawable.ic_dialog_alert);
                    dialog.setCancelable(false);
                    dialog.setPositiveButton("OK", new DialogInterface.OnClickListener()
                    {
                        public void onClick(DialogInterface dialog, int which)
                        {

                        }
                    });
                    dialog.show();
                }

                apStatusText.setText(statusText);
            }
        });
    }

    public static void setApScanButton( Button apScanButton )
    {
        ViewUtils.apScanButton = apScanButton;
    }

    public static void setApScanButtonEnabled( final boolean isEnable )
    {
        apListActivity.runOnUiThread( new Runnable()
        {
            public void run()
            {
                apScanButton.setEnabled(isEnable);
                if (isRescanEnabled && isEnable)
                {
                    Log.i("OPL1000", "Current WIFI_SCAN Count: " + (++rescanCount));
                    apScanButton.performClick();
                }
            }
        });
    }

    public static void setApListAdapter(ApListAdapter apListAdapter)
    {
        ViewUtils.apListAdapter = apListAdapter;
    }

    public static void refreshApList()
    {
        apListActivity.runOnUiThread( new Runnable()
        {
            public void run()
            {
                apListAdapter.notifyDataSetChanged();
            }
        });
    }
}
