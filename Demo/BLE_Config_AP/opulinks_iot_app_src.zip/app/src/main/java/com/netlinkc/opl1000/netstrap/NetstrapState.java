package com.netlinkc.opl1000.netstrap;

public enum NetstrapState {

    /* establish ble connection for netstrap */

    TO_SCAN_DEVICE,

    TO_CONNECT_DEVICE,

    TO_EXCHANGE_MTU,

    TO_DISCOVER_SERVICE,

    TO_READ_CHARACTERISTIC,

    /*  start netstrap application behavior */

    TO_INDICATE_DEVICE_SCAN_AP,

    TO_INDICATE_DEVICE_CONNECT_AP,

    TO_READ_DEVICE_INFO,

    TO_WRITE_DEVICE_INFO,

    TO_READ_FIRMWARE_VERSION,

    OTA_START,

    OTA_SEND,

    OTA_END,

    TO_PROCESS_RX_PACKET,

    TO_CAL_VBATT,

    TO_CAL_IO_VOL,

    TO_CAL_TEMP,

    /* finalize netstrap application */

    TO_TERMINATE

}
