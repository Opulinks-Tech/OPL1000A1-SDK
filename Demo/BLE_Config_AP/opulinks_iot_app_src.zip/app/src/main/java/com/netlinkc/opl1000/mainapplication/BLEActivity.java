package com.netlinkc.opl1000.mainapplication;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanRecord;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.net.wifi.ScanResult;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelUuid;
import android.os.SystemClock;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.BaseAdapter;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View.OnClickListener;

import com.netlinkc.opl1000.netstrap.BeanFactory;
import com.netlinkc.opl1000.netstrap.BleService;
import com.netlinkc.opl1000.netstrap.LogService;
import com.netlinkc.opl1000.netstrap.NetstrapService;
import com.netlinkc.opl1000.netstrap.NetstrapState;
import com.netlinkc.opl1000.netstrap.NetstrapTask;
import com.netlinkc.opl1000.netstrap.OtaService;

import java.io.UnsupportedEncodingException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class BLEActivity extends AppCompatActivity
{
    private static final int REQUEST_CODE_LOCATION_SETTINGS = 2;
    private static final int REQUEST_CODE_ACCESS_COARSE_LOCATION = 1;
    // private LeDeviceListAdapter mLeDeviceListAdapter;
    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private Handler mHandler;
    private static final long SCAN_PERIOD = 30000;

    private int                          mConnectCount = 0;
    private ArrayList<BluetoothDevice>   mLeDevices;

    private final static int REQUEST_ENABLE_BLE = 0x1001;
    private static final int FILE_SELECT_CODE = 0x1002;
    private boolean isApViewEverEntered;

    // BleService                                  bleService;
    ListView                                    listview;
    public ArrayList<HashMap<String, Object>>   arraylist = new ArrayList<HashMap<String, Object>>();
    private List<byte[]>                        RawBytesList = new ArrayList<byte[]>();
    public SimpleAdapter                        adapter;
    private ProgressDialog                      ProgDialog;
    HashMap<String, String>                     DeviceNameTimelist = new HashMap<String, String>();
    private int editableItemId=-1;


    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        mHandler = new Handler();
        setContentView( R.layout.ble_activity );

        mLeDevices = new ArrayList<BluetoothDevice>();
        listview = (ListView) findViewById( R.id.listView1 );

        IntentFilter FunctionFilter = new IntentFilter();

        FunctionFilter.addAction( "com.netlinkc.opl1000.DisConnectedBLE" );
        registerReceiver( BroadcastAction, FunctionFilter );

        this.adapter = new SimpleAdapter( BLEActivity.this, arraylist, R.layout.ble_list,
                                           new String[] { "ssid", "mac", "bound", "dBm", "ms", "type", "uuids", "txpower", "img", "flags",
                                                          "completeln", "uuids16", "servicedata", "conintrange", "appearance", "manufacturerdata"},
                                           new int[] { R.id.ssid, R.id.mac, R.id.bound, R.id.sigstr, R.id.msstr, R.id.Type, R.id.UUIDs,
                                                       R.id.TxPower, R.id.img, R.id.Flags, R.id.CompleteLN, R.id.UUIDs16, R.id.ServiceData,
                                                       R.id.Con_Int_Range, R.id.Appearance, R.id.ManufacturerData } )
        {




            public void setEditablePosition(int position){
                editableItemId = position;
                notifyDataSetChanged();
            }

            public View getView( final int position, View convertView, ViewGroup parent )
            {
                final View   vLayout = super.getView( position, convertView, parent );
                Button       ConnectBut = (Button) vLayout.findViewById( R.id.Connect_btn );

                TextView FlagsView = (TextView) vLayout.findViewById( R.id.Flags );
                TextView TxPower = (TextView) vLayout.findViewById( R.id.TxPower );
                TextView UUIDsView = (TextView) vLayout.findViewById( R.id.UUIDs );
                TextView CompleteLN = (TextView) vLayout.findViewById( R.id.CompleteLN );
                TextView UUIDs16 = (TextView) vLayout.findViewById( R.id.UUIDs16 );
                TextView ServiceData = (TextView) vLayout.findViewById( R.id.ServiceData );
                TextView Con_Int_Range = (TextView) vLayout.findViewById( R.id.Con_Int_Range );
                TextView Appearance = (TextView) vLayout.findViewById( R.id.Appearance );
                TextView ManufacturerData = (TextView) vLayout.findViewById( R.id.ManufacturerData );
                // TextView Rawbtn = (TextView) vLayout.findViewById( R.id.Raw );
                final    TextView mac = (TextView) vLayout.findViewById( R.id.mac );

                final Button otaBtn;
                otaBtn = (Button) vLayout.findViewById(R.id.ota1Btn);   // init otaButton



                if(position == editableItemId){
                    otaBtn.setVisibility(View.VISIBLE);
                    otaBtn.setEnabled(true);
                } else {
                    otaBtn.setVisibility(View.INVISIBLE);
                    otaBtn.setEnabled(false);
                }



                if( FlagsView.getText().length() == 0 )
                    FlagsView.setVisibility( View.GONE );
                else
                   FlagsView.setVisibility( View.VISIBLE );

                if( UUIDsView.getText().length() == 0 )
                    UUIDsView.setVisibility( View.GONE );
                else
                   UUIDsView.setVisibility( View.VISIBLE );

                if( CompleteLN.getText().length() == 0 )
                    CompleteLN.setVisibility( View.GONE );
                else
                   CompleteLN.setVisibility( View.VISIBLE );

                if( UUIDs16.getText().length() == 0 )
                    UUIDs16.setVisibility( View.GONE );
                else
                   UUIDs16.setVisibility( View.VISIBLE );

                if( ServiceData.getText().length() == 0 )
                    ServiceData.setVisibility( View.GONE );
                else
                   ServiceData.setVisibility( View.VISIBLE );

                if( Con_Int_Range.getText().length() == 0 )
                    Con_Int_Range.setVisibility( View.GONE );
                else
                   Con_Int_Range.setVisibility( View.VISIBLE );

                if( Appearance.getText().length() == 0 )
                    Appearance.setVisibility( View.GONE );
                else
                   Appearance.setVisibility( View.VISIBLE );

                if( TxPower.getText().length() == 0 )
                    TxPower.setVisibility( View.GONE );
                else
                   TxPower.setVisibility( View.VISIBLE );

                if( ManufacturerData.getText().length() == 0 )
                    ManufacturerData.setVisibility( View.GONE );
                else
                   ManufacturerData.setVisibility( View.VISIBLE );


                ConnectBut.setOnClickListener( new OnClickListener()
                {
                    public void onClick( View arg0 )
                    {
                        if( mScanning )
                            scanLeDevice(false);

                        if( MainActivity.bleService.bleGattClient != null )
                            MainActivity.bleService.bleGattClient.disconnect();

                        Toast.makeText(BLEActivity.this,"Connect to( " + mac.getText() + " ) !", Toast.LENGTH_SHORT).show();
                        MainActivity.bleService.ConnectBLE( (String) mac.getText() );

                        ProgDialog = new ProgressDialog(BLEActivity.this);
                        ProgDialog.getWindow().setBackgroundDrawable( new ColorDrawable(android.graphics.Color.TRANSPARENT) );
                        ProgDialog.setIndeterminate( true );
                        ProgDialog.setCancelable( false );
                        ProgDialog.show();
                        ProgDialog.setContentView( R.layout.progress_dlg );

                        final Handler ConnectHandler = new Handler();

                        mConnectCount = 0;
                        ConnectHandler.post(new Runnable()
                        {
                            public void run()
                            {
                                TextView   DeviceInfo = (TextView) findViewById( R.id.DeviceInfo );
                                TextView   DeviceMac = (TextView) findViewById( R.id.DeviceMac );

                                if( mConnectCount < 100 )
                                {
                                    // Log.e("ConnectHandler", "mConnectCount = " + mConnectCount );
                                    if( MainActivity.bleService.bleStatus == 3 )   // BLE_STATUS_CONNECTED
                                    {
                                        mConnectCount = 101;
                                        ProgDialog.dismiss();
                                        MainActivity.ScanApList = true;

                                        // finish();
                                        // overridePendingTransition(0, 0 );

                                        TextView   ssid = (TextView) vLayout.findViewById( R.id.ssid );
                                        TextView   mac = (TextView) vLayout.findViewById( R.id.mac );


                                        MainActivity.CurrentBLE = ssid.getText().toString();
                                        MainActivity.CurrentBLEMac = mac.getText().toString();
                                        DeviceInfo.setText( MainActivity.CurrentBLE );
                                        DeviceMac.setVisibility( View.VISIBLE );
                                        DeviceMac.setText( MainActivity.CurrentBLEMac );


                                        //MainActivity.bleService.exchangeMtu();
                                        setEditablePosition(position);
                                        otaBtn.setOnClickListener(new View.OnClickListener()
                                        {

                                            public void onClick(View view)
                                            {
                                                //showFileChooser();
                                                Intent intent = new Intent(BLEActivity.this, BleEngActivity.class);
                                                startActivity(intent);
                                                overridePendingTransition(0, 0);


                                            }

                                        });
                                    }
                                    else if( MainActivity.bleService.bleStatus == 2 )   // BLE_STATUS_CONNECTING
                                    {
                                             // Log.e("ConnectHandler", "postDelayed postDelayed postDelayed" );
                                             ConnectHandler.postDelayed(this, 100);
                                    }
                                    else
                                       ConnectHandler.postDelayed(this, 100);

                                    mConnectCount++;
                                }
                                else
                                {
                                    ProgDialog.dismiss();
                                    MainActivity.ScanApList = false;
                                    DeviceInfo.setText( "Device" );
                                    DeviceMac.setVisibility( View.GONE );

                                    Log.e( "postDelayed", "bleService.bleStatus = "+ MainActivity.bleService.bleStatus );
                                    Toast.makeText(BLEActivity.this,"Connection failed( " + mac.getText() + " ) !", Toast.LENGTH_SHORT).show();
                                    scanLeDevice(true);
                                }
                            }
                        });
                    }
                });
                return vLayout;
            }
        };

        TextView   DeviceInfo = (TextView) findViewById( R.id.DeviceInfo );
        TextView   DeviceMac = (TextView) findViewById( R.id.DeviceMac );

        Log.e("rrrrrrrrrrrrrrrrrrrr", "CurrentBLE = " + MainActivity.CurrentBLE );
        if( MainActivity.CurrentBLE.length() == 0 )
        {
            DeviceInfo.setText( "Device" );
            DeviceMac.setVisibility(View.GONE);
        }
        else
        {
           if( !MainActivity.ScanApList || MainActivity.bleService.bleGattClient == null )
           {
               Log.e("wwwwwwwwwwwwwwww = " + MainActivity.ScanApList, "CurrentBLE = " + MainActivity.bleService.bleGattClient );
               DeviceMac.setVisibility( View.GONE );
               DeviceInfo.setText( "Device" );
           }
           else
           {
              DeviceInfo.setText(MainActivity.CurrentBLE);
              DeviceMac.setVisibility(View.VISIBLE);
              DeviceMac.setText(MainActivity.CurrentBLEMac);
           }
        }

        listview.setAdapter( adapter );
        // mLeDeviceListAdapter = new LeDeviceListAdapter(BLEActivity.this);
        // listview.setAdapter( mLeDeviceListAdapter );

        listview.setOnItemClickListener(onClickListView);
        listview.setItemsCanFocus(false);

        getSupportActionBar().hide();


        ViewUtils.setMainActivity(this);   // init mainActivity

        Button otaButton = (Button) findViewById(R.id.otaButton);   // init otaButton
        otaButton.setEnabled(false);
        otaButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                showFileChooser();
            }
        });
        ViewUtils.setOtaButton(otaButton);

        Button apControlButton = (Button) findViewById(R.id.apControlButton);   // init apControlButton
        apControlButton.setEnabled(false);
        apControlButton.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                startApListActivity();
            }
        });
        ViewUtils.setApControlButton(apControlButton);

        TextView logText = (TextView) findViewById(R.id.logText);   // init logText
        ViewUtils.setLogText(logText);

//        LogService.initial();   // init logService

        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE))   // check whether support ble
        {
//            LogService.log("BLE is not supported.");
        }
        else
        {
//            LogService.log("BLE is supported.");

            mBluetoothAdapter = ((BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();   // enable bluetooth
            if( mBluetoothAdapter == null || !mBluetoothAdapter.isEnabled() )
            {
                Log.e("123", "bleAdapter == null" );
                Intent intent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(intent, REQUEST_ENABLE_BLE);
            }
            else
            {
                if( mBluetoothAdapter != null )
                    Log.e("456", "bleAdapter != null" );

                if( mBluetoothAdapter.isEnabled() )
                    Log.e("456", "bleAdapter.isEnabled()" );

                //TODO
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                                Manifest.permission.ACCESS_COARSE_LOCATION)) {
                            Toast.makeText(this, "Android 6.0", Toast.LENGTH_SHORT).show();
                        }

                        ActivityCompat.requestPermissions(this,
                                new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                                REQUEST_CODE_ACCESS_COARSE_LOCATION);
                    }
                }

                scanLeDevice(true);

                startNetstrapService();
            }
        }

        TextView ScanBut= (TextView) findViewById(R.id.ScanBut);
        ScanBut.setOnClickListener(new OnClickListener()
        {
           public void onClick(View arg0)
           {
               ProgressBar   ProgBar = (ProgressBar) findViewById( R.id.ScanProg );
               TextView      ScanBut = (TextView) findViewById( R.id.ScanBut );

               if( ScanBut.getText().equals("Scan") )
               {
                   Toast.makeText(BLEActivity.this,"Start Scan !", Toast.LENGTH_SHORT ).show();
                   ProgBar.setVisibility( View.VISIBLE );
                   ScanBut.setText( "Stop Scanning..." );

                   arraylist.clear();
                   mLeDevices.clear();
                   RawBytesList.clear();
                   DeviceNameTimelist.clear();
                   adapter.notifyDataSetChanged();

                   scanLeDevice(true);

                   editableItemId=-1;
                   if( MainActivity.bleService.bleGattClient != null )
                       MainActivity.bleService.bleGattClient.disconnect();
               }
               else
               {
                   Toast.makeText(BLEActivity.this,"Stop Scan !", Toast.LENGTH_SHORT ).show();
                   ProgBar.setVisibility( View.INVISIBLE );
                   ScanBut.setText( "Scan" );
                   scanLeDevice(false);
               }
           }
        });
    }


    private List<HashMap<String, Object>> getRawData( int position )
    {
        int                                  index = 0;
        ArrayList<HashMap<String, Object>>   RawDataList = new ArrayList<HashMap<String, Object>>();
        byte[]                               scanRecord = RawBytesList.get( position );


        while( index < scanRecord.length )
        {
           HashMap<String, Object>   rawmap = new HashMap<String, Object>();
           int                       length = scanRecord[index++];

           if( length == 0 )   //Done once we run out of records
               break;

           byte type = scanRecord[index];
           if( type == 0 )   //Done if our record isn't a valid type
               break;

           byte[] data = Arrays.copyOfRange(scanRecord, index + 1, index + length);

           rawmap.put( "len", length );
           rawmap.put( "type", String.format("%02x", type) );
           rawmap.put( "value", bytesToHex(data, false) );
           RawDataList.add( rawmap );

           index += length;
        }

        return RawDataList;
    }


    private BroadcastReceiver BroadcastAction = new BroadcastReceiver()
    {
       public void onReceive( Context context, Intent intent )
       {
          if( intent.getAction().equals("com.netlinkc.opl1000.DisConnectedBLE") )
          {
              TextView   DeviceInfo = (TextView) findViewById( R.id.DeviceInfo );
              TextView   DeviceMac = (TextView) findViewById( R.id.DeviceMac );


              DeviceInfo.setText( "Device" );
              DeviceMac.setVisibility( View.GONE );

              if( MainActivity.bleService.bleGattClient != null )
                  MainActivity.bleService.bleGattClient.close();

              ShowAlertDialog("OPL1000 device disconnected !", "Warning Message");
          }
       }
    };


    private void ShowAlertDialog(String SMessage, String STitel)
    {
       AlertDialog.Builder   alertdialog = new AlertDialog.Builder(BLEActivity.this);


       alertdialog.setTitle(STitel);
       alertdialog.setMessage(SMessage);

       DialogInterface.OnClickListener OkClick = new DialogInterface.OnClickListener()
       {
          public void onClick(DialogInterface dialog, int which)
          {

          }
       };

       alertdialog.setNegativeButton("OK", OkClick );
       alertdialog.show();
    }


    private void scanLeDevice(final boolean enable)
    {
        final ProgressBar   ProgBar = (ProgressBar) findViewById( R.id.ScanProg );
        final TextView      ScanBut = (TextView) findViewById( R.id.ScanBut );

        if( enable )
        {
            mHandler.postDelayed( new Runnable()
            {
                public void run()
                {
                    mScanning = false;
                    mBluetoothAdapter.stopLeScan(BLEActivity.this.mLeScanCallback);

                    ProgBar.setVisibility( View.INVISIBLE );
                    ScanBut.setText( "Scan" );
                }
            }, SCAN_PERIOD );

            mScanning = true;
            mBluetoothAdapter.startLeScan(BLEActivity.this.mLeScanCallback);
            ProgBar.setVisibility( View.VISIBLE );
            ScanBut.setText( "Stop Scanning..." );


            final Handler NotifyHandler = new Handler();

            NotifyHandler.post(new Runnable()
            {
                public void run()
                {
                    if( mScanning )
                    {
                        adapter.notifyDataSetChanged();
                        NotifyHandler.postDelayed(this, 100);
                    }
                }
            });

        }
        else
        {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(BLEActivity.this.mLeScanCallback);


            ProgBar.setVisibility( View.INVISIBLE );
            ScanBut.setText( "Scan" );
        }
    }


    public String bytesToHex(byte[] bytes, boolean BLE)
    {
        int      index;
        char[]   hexArray = "0123456789ABCDEF".toCharArray();

        if( BLE )
        {
            index = 0;
            while( index < bytes.length )
            {
                int length = bytes[index++];
                if( length == 0 )   //Done once we run out of records
                    break;

                byte type = bytes[index];
                if( type == 0 )   //Done if our record isn't a valid type
                    break;

                index += length;
            }

            index--;
        }
        else
           index =  bytes.length;

        char[] hexChars = new char[index * 2];
        for (int j = 0; j < index; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }

    String StringdeviceTypeTyString(int paramInt)
    {
        switch(paramInt)
        {
            default:

                return "UNKNOWN";
            case 1:

                return "CLASSIC";
            case 3:

                return "CLASSIC and BLE";
            case 2:
        }

        return "BLE only";
    }


    private BluetoothAdapter.LeScanCallback mLeScanCallback = new BluetoothAdapter.LeScanCallback()
    {
        public void onLeScan(final BluetoothDevice device, final int rssi, final byte[] scanRecord)
        {
            if( Looper.myLooper() == Looper.getMainLooper() )   // Android 5.0
            {
                BLEAddItem( device, rssi, scanRecord );
            }
            else
            {
                runOnUiThread(new Runnable()
                {
                    public void run()
                    {
                       BLEAddItem( device, rssi, scanRecord );
                    }
                });
            }
        }
    };


    void BLEAddItem( BluetoothDevice device, final int rssi, final byte[] scanRecord )
    {
        long                      Now_time = SystemClock.uptimeMillis();
        HashMap<String, Object>   rawmap = new HashMap<String, Object>();
        HashMap<String, Object>   item = new HashMap<String, Object>();
        String                    deviceName = device.getName();


        if( !mLeDevices.contains(device) )
            DeviceNameTimelist.put( device.getAddress(), String.valueOf(Now_time) );
        else
        {
            int       ii = 0;
            long      tmplong = 0;
            boolean   ChkStatus = false;

            for( String key : DeviceNameTimelist.keySet() )
            {
                if( key != null && key.equals(device.getAddress()) )
                {
                    ChkStatus = true;
                    tmplong = Now_time - Integer.valueOf( DeviceNameTimelist.get(device.getAddress()) );
                    DeviceNameTimelist.put( device.getAddress(), String.valueOf(Now_time) );

                    // Log.e("DeviceNameTimelist = " + tmplong, "key : " + key + " befo = " + DeviceNameTimelist.get(device.getAddress()) + " aft = " + Now_time);
                    break;
                }

                ii++;
            }

            if( ChkStatus )
            {
                arraylist.get(ii).put("ms", String.valueOf(tmplong) + " ms");
                arraylist.get(ii).put("dBm", String.valueOf(rssi) + " dBm");
            }

            return;
        }

        if( deviceName == null )
            item.put( "ssid", "UnKnown device" );
        else
            item.put( "ssid", deviceName );

        item.put( "mac", device.getAddress() );
        item.put( "ms", " 23 ms" );

        switch( device.getBondState() )
        {
            case BluetoothDevice.BOND_NONE:

                item.put( "bound", "Not Bonded" );
                break;
            case BluetoothDevice.BOND_BONDING:

                item.put( "bound", "Not Bonded" );
                break;
            case BluetoothDevice.BOND_BONDED:

                item.put( "bound", "Bonded" );
                break;
        }

        item.put( "dBm", rssi + " dBm" );

        int       startByte = 2;
        boolean   patternFound = false;

        while( startByte <= 5 )
        {
            if( ((int) scanRecord[startByte + 2] & 0xff) == 0x02 &&
                ((int) scanRecord[startByte + 3] & 0xff) == 0x15 )
            {
                patternFound = true;
                break;
            }

            startByte++;
        }

        String DType = StringdeviceTypeTyString(device.getType());
        item.put( "type", "Type : " + DType );

        if( DType.equals( "UNKNOWN" ) )
            item.put( "img", R.drawable.unknow );
        else
           item.put( "img", R.drawable.bluetooth );

        RawBytesList.add(scanRecord);
        arraylist.add( item );
        adapter.notifyDataSetChanged();
        mLeDevices.add(device);
    }

    private AdapterView.OnItemClickListener onClickListView = new AdapterView.OnItemClickListener()
    {
        public void onItemClick( AdapterView<?> parent, View view, int position, long id )
        {
           View layout1 = view.findViewById(R.id.BLEDetailLayout);

           if( layout1.getVisibility() == View.VISIBLE )
               layout1.setVisibility(View.GONE);
           else
              layout1.setVisibility(View.VISIBLE);
        }
    };

    private void showFileChooser()
    {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);

        try
        {
            startActivityForResult(Intent.createChooser(intent, "Select a File to Upload"), FILE_SELECT_CODE);
        }
        catch( android.content.ActivityNotFoundException ex )
        {
            Toast.makeText(this, "Please install a File Manager.", Toast.LENGTH_SHORT).show();
        }
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        switch(requestCode)
        {
            case REQUEST_ENABLE_BLE:
                if( resultCode == RESULT_OK )
                {
//                    LogService.log("Enabling ble request is successful.");
                    startNetstrapService();
                }
                else
                {
 //                   LogService.log("Please permit enabling ble request.");
                }
                break;
            case FILE_SELECT_CODE:

                if( resultCode == RESULT_OK )
                {
                    Uri uri = data.getData();
                    String path = uri.getPath();
                    Log.i("OPL1000", path);
                    BeanFactory.getOtaService().setOtaImagePath(uri);
                    BeanFactory.getNetstrapService().addTask(new NetstrapTask(NetstrapState.OTA_START));
                }
                else
                {
//                    LogService.log("Please choose correct OTA image.");
                }
                break;
        }
    }

    private void injectDependency()
    {
        MainActivity.bleService.MessageContext = BLEActivity.this;

        NetstrapService netstrapService = new NetstrapService();
        OtaService otaService = new OtaService();

        MainActivity.bleService.setNetstrapService(netstrapService);
        netstrapService.setBleService( MainActivity.bleService );
        netstrapService.setOtaService(otaService);
        BeanFactory.setNetstrapService(netstrapService);
        BeanFactory.setOtaService(otaService);
    }

    private void startNetstrapService()
    {
//        LogService.log("BLE function is ready.");
        injectDependency();

//        LogService.log("Starting OPL1000 BLE/WiFi demo scenario.");
        BeanFactory.getNetstrapService().start();
        BeanFactory.getNetstrapService().addTask(new NetstrapTask(NetstrapState.TO_SCAN_DEVICE));
    }

    void startApListActivity()
    {
        Intent intent = new Intent(BLEActivity.this, ApListActivitiy.class);
        intent.putExtra("isApViewEverEntered", isApViewEverEntered);
        isApViewEverEntered = true;
        startActivity(intent);
    }

    @Override
    public void onBackPressed()
    {
        finish();

        overridePendingTransition(0, 0);
    }

    protected void onResume()
    {
        super.onResume();

              scanLeDevice(true);
    }

    protected void onPause()
    {
        super.onPause();

        scanLeDevice(false);

        mLeDevices.clear();
        arraylist.clear();
        RawBytesList.clear();
        DeviceNameTimelist.clear();
    }

    @Override
    protected void onDestroy()
    {
        super.onDestroy();

        unregisterReceiver(BroadcastAction);

        if( !MainActivity.ScanApList )
        {
            if (BeanFactory.getNetstrapService() != null)
                BeanFactory.getNetstrapService().end();
        }
    }
}
