package com.netlinkc.opl1000.netstrap;

import android.content.Intent;
import android.util.Log;

import com.netlinkc.opl1000.mainapplication.MainActivity;
import com.netlinkc.opl1000.mainapplication.ViewUtils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;

public class NetstrapService extends Thread {

    private final static int OTA_MAX_RX_OCTETS = 5;

    private BleService bleService;

    private OtaService otaService;

    private boolean isOtaStarted;

    private BlockingQueue<NetstrapTask> taskQueue = new LinkedBlockingDeque<>();

    private List<ApInfo> apList = new ArrayList<>();

    private ApInfo connectingAp;

    private int otaIndex = 0;

    private boolean isOtaPaused;

    private long otaStartTime;

    private long otaEndTime;

    public void setBleService(BleService bleService) {
        this.bleService = bleService;
    }

    public BleService getBleService() {
        return this.bleService;
    }

    public void setOtaService(OtaService otaService) {
        this.otaService = otaService;
    }

    public boolean isOtaStarted() {
        return isOtaStarted;
    }

    Comparator<ApInfo> myComparator = new Comparator<ApInfo>()
    {
        public int compare( ApInfo obj1, ApInfo obj2 )
        {
            // return obj1.getName().compareTo(obj2.getName());

            if( obj1.getRssi() >= obj2.getRssi() )
                return -1;
            else
               return 1;
        }
    };

    public void addTask(NetstrapTask task) {
        try {
            taskQueue.put(task);
            if (task.getState() != NetstrapState.OTA_SEND && !isOtaStarted) {
                if(task.getState() != NetstrapState.TO_SCAN_DEVICE)
                    LogService.log("\n  ->  [" + task.getState() + "]");
            }
        } catch (InterruptedException e) {
            Log.e(NetstrapService.class.getName(), e.getMessage(), e);
        }
    }

    public List<ApInfo> getApList() {
        return apList;
    }

    private void scanWifiAp(boolean isShowHidden, int scanType) {
        apList.clear();
        ViewUtils.refreshApList();
        ViewUtils.setApScanButtonEnabled(false);
        ViewUtils.updateApStatus("Scanning AP Start");

        NetstrapPacket pkt = NetstrapPacket.createScanReqPacket(true, scanType);
        LogService.log(pkt.toString());
        Log.e( "scanWifiAp", pkt.toString() );
        bleService.send(pkt.getBytes());
    }

    private void connectWifiAp(ApInfo apInfo, String password, int ConnectStatus) {
        connectingAp = apInfo;
        ViewUtils.updateApStatus("[" + apInfo.getSsid() + " is connecting...");
        Log.e( "connectWifiAp", "[" + apInfo.getSsid() + " is connecting..." );

        NetstrapPacket pkt = NetstrapPacket.createConnectReqPacket(apInfo.getBssid(), password, ConnectStatus);
        LogService.log(pkt.toString());
        Log.e( "connectWifiAp", pkt.toString() );
        bleService.send(pkt.getBytes());
    }

    private void readDeviceInfo() {
        NetstrapPacket pkt = NetstrapPacket.createReadDeviceInfoReqPacket();
        LogService.log(pkt.toString());
        Log.e( "readDeviceInfo", pkt.toString() );
        bleService.send(pkt.getBytes());
    }

    private void writeDeviceInfo(byte[] deviceId, String manufactureName) {
        NetstrapPacket pkt = NetstrapPacket.createWriteDeviceInfoReqPacket(deviceId, manufactureName);
        LogService.log(pkt.toString());
        Log.e( "writeDeviceInfo", pkt.toString() );
        bleService.send(pkt.getBytes());
    }

    private void readFirmwareVersion() {
        NetstrapPacket pkt = NetstrapPacket.createOtaVersionReqPacket();
        LogService.log(pkt.toString());
        bleService.send(pkt.getBytes());
    }

    private void vbattcalStart(float fvbatt) {
            NetstrapPacket pkt = NetstrapPacket.createcalvbattPacket(fvbatt);
            LogService.log(pkt.toString());
            Log.i("OPL1000 vbatt cal", Float.toString(fvbatt));
            bleService.send(pkt.getBytes());
    }

    private void iovolcalStart(byte IOPin, float fiovol) {
        NetstrapPacket pkt = NetstrapPacket.createcaliovolPacket(IOPin, fiovol);
        LogService.log(pkt.toString());
        Log.i("OPL1000 I/O Vol. cal", Float.toString(fiovol));
        bleService.send(pkt.getBytes());
    }

    private void tempcalStart(float ftemp) {
        NetstrapPacket pkt = NetstrapPacket.createcaltempPacket(ftemp);
        LogService.log(pkt.toString());
        Log.i("OPL1000 Temp. cal", Float.toString(ftemp));
        bleService.send(pkt.getBytes());
    }

    private void otaStart() {
        OtaImage otaImage = otaService.getOtaImage();

        if (otaImage != null) {
            byte[] otaHeader = otaImage.getHeader();
            NetstrapPacket pkt = NetstrapPacket.createOtaUpgradeReqPacket(OTA_MAX_RX_OCTETS, otaHeader);
            LogService.log(pkt.toString());
            Log.i("OPL1000", otaImage.toString());
            bleService.send(pkt.getBytes());
        } else {
            LogService.log("OTA image is incorrect.");
        }
    }

    private void otaSend() {
        OtaImage otaImage = otaService.getOtaImage();
        byte[] rawData = otaImage.getRawData();

        if (rawData != null) {
            NetstrapPacket pkt = NetstrapPacket.createOtaRawDataReqPacket(rawData);
            //LogService.log(pkt.toString());
            bleService.send(pkt.getBytes());
            isOtaStarted = true;
//            if(ViewUtil1.getMainActivity()!=null)
//                ViewUtil1.logAppendNumberSign("#");
//            else if(ViewUtil2.getMainActivity()!=null)
//                ViewUtil2.logAppendNumberSign("#");
            ViewUtils.logAppendNumberSign("#");
            otaIndex++;
            if (otaIndex == OTA_MAX_RX_OCTETS) {
                isOtaPaused = true;
            }
        } else {
            otaEndTime = System.currentTimeMillis();
            isOtaStarted = false;
            otaService.resetOtaImage();
            otaEnd();
        }
    }

    private void otaEnd() {
//        if(ViewUtil1.getMainActivity()!=null)
//            ViewUtil1.logAppendNumberSign("\n");
//        else if(ViewUtil2.getMainActivity()!=null)
//            ViewUtil2.logAppendNumberSign("\n");
        ViewUtils.logAppendNumberSign("\n");
        NetstrapPacket pkt = NetstrapPacket.createOtaEndReqPacket(0);
        LogService.log(pkt.toString());
        bleService.send(pkt.getBytes());
    }

    private void processRxPacket(NetstrapPacket packet) {
        switch (packet.getCmdId()) {
            case NetstrapPacket.PDU_TYPE_EVT_SCAN_RSP:

                if( packet.ApConnectStatus == 1 )
                {
                    Intent intent = new Intent("com.netlinkc.opl1000.ConnectedItem");

                    intent.putExtra("ssid", packet.getSsid());
                    intent.putExtra("bssid", NetstrapPacket.getMacAddress(packet.getBssid()) );
                    intent.putExtra("authMode", packet.getAuthMode());
                    intent.putExtra("rssi", packet.getRssi());
                    intent.putExtra("ApConnectStatus", packet.ApConnectStatus);

                    MainActivity.bleService.MessageContext.sendBroadcast(intent);
                    // Log.e("PDU_TYPE_EVT_SCAN_RSP", "ApConnectStatus == " + packet.getSsid());
                }
                else
                {
                    apList.add(new ApInfo(packet));

                    Collections.sort(apList, myComparator);

                    ViewUtils.refreshApList();
                    // Log.e("PDU_TYPE_EVT_SCAN_RSP", "ApConnectStatus == 0");
                }
                break;

            case NetstrapPacket.PDU_TYPE_EVT_SCAN_END:
                ViewUtils.setApScanButtonEnabled(true);
                ViewUtils.updateApStatus("Scanning AP End");
                Log.e( "PDU_TYPE_EVT_SCAN_END", "Scanning AP End" );

                Intent intent = new Intent("com.netlinkc.opl1000.ScanAPEnd");

                MainActivity.bleService.MessageContext.sendBroadcast(intent);

                break;

            case NetstrapPacket.PDU_TYPE_EVT_CONNECT_RSP:
                connectingAp.setConnectStatus(packet.getConnectStatus());
                ViewUtils.refreshApList();
                ViewUtils.updateApStatus("[" + connectingAp.getSsid() + "]" + (connectingAp.isConnected() ? " is connected" : " connecting failed"));

                Log.e( "TYPE_EVT_CONNECT_RSP", "[" + connectingAp.getSsid() + "]" + (connectingAp.isConnected() ? " is connected" : " connecting failed") );
                break;

            case NetstrapPacket.PDU_TYPE_EVT_READ_DEVICE_INFO_RSP:
                break;

            case NetstrapPacket.PDU_TYPE_EVT_WRITE_DEVICE_INFO_RSP:
                break;

            case NetstrapPacket.PDU_TYPE_EVT_OTA_VERSION_RSP:
                //ViewUtils.setOtaButtonEnabled(true);
                //ViewUtils.setApControlButtonEnabled(true);
                break;

            case NetstrapPacket.PDU_TYPE_EVT_OTA_UPGRADE_RSP:
                if (packet.getStatus() == 0x00) {
                    otaStartTime = System.currentTimeMillis();
                    isOtaStarted = true;
                    isOtaPaused = false;
                    otaIndex = 0;
                    otaSend();
                }
                break;

            case NetstrapPacket.PDU_TYPE_EVT_OTA_RAW_DATA_RSP:
                otaIndex = 0;
                isOtaPaused = false;
                ViewUtils.logAppendNumberSign(" ");
                otaSend();
                break;

            case NetstrapPacket.PDU_TYPE_EVT_OTA_END_RSP:
                MainActivity.bleService.disconnect();
                if (packet.getReason() != 0x00) {
                    isOtaStarted = false;
                    LogService.log(" ***** OTA failed: " + packet.getReason());
                } else {
                    LogService.log(" ***** OTA time: " + (otaEndTime - otaStartTime));
                }
                break;
        }
    }

    @Override
    public void run() {
        try {
            NETSTRAP_LOOP:
            while (true) {
                NetstrapTask task = taskQueue.take();

                switch (task.getState()) {
                    //Kevin add for calibration
                    case TO_CAL_VBATT:
                        float vol=(float)task.getData("Voltage");
                        vbattcalStart(vol);
                        break;

                    case TO_CAL_IO_VOL:
                        float voltage=(float)task.getData("IOVoltage");
                        Byte Pin=(Byte)task.getData("IOPIN");
                        iovolcalStart(Pin, voltage);
                        break;

                    case TO_CAL_TEMP:
                        float temp=(float)task.getData("Temperture");
                        tempcalStart(temp);
                        break;

                    case TO_SCAN_DEVICE:
                        bleService.scan();
                        break;

                    case TO_CONNECT_DEVICE:
                        bleService.connect();
                        break;

                    case TO_EXCHANGE_MTU:
                        bleService.exchangeMtu();
                        break;

                    case TO_DISCOVER_SERVICE:
                        bleService.discover();
                        break;

                    case TO_READ_CHARACTERISTIC:
                        bleService.readCharacteristic();
                        break;

                    case TO_INDICATE_DEVICE_SCAN_AP:
                        boolean isShowHidden = (Boolean) task.getData("isShowHidden");
                        int scanType = (Integer) task.getData("scanType");
                        scanWifiAp(isShowHidden, scanType);
                        break;

                    case TO_INDICATE_DEVICE_CONNECT_AP:
                        ApInfo apInfo = (ApInfo) task.getData("apInfo");
                        String password = (String) task.getData("password");
                        int ConnectStatus = (int) task.getData("ConnectStatus");
                        connectWifiAp(apInfo, password, ConnectStatus);
                        break;

                    case TO_READ_DEVICE_INFO:
                        readDeviceInfo();
                        break;

                    case TO_WRITE_DEVICE_INFO:
                        byte[] deviceId = (byte[]) task.getData("deviceId");
                        String manufactureName = (String) task.getData("manufactureName");
                        writeDeviceInfo(deviceId, manufactureName);
                        break;

                    case TO_READ_FIRMWARE_VERSION:
                        readFirmwareVersion();
                        break;

                    case OTA_START:
                        otaStart();
                        break;

                    case OTA_SEND:
                        if (!isOtaPaused) {
                            otaSend();
                        }
                        break;

                    case OTA_END:
                        break;

                    case TO_PROCESS_RX_PACKET:
                        NetstrapPacket packet = (NetstrapPacket) task.getData("netstrapPacket");
                        if (!isOtaStarted) {
                            LogService.log(packet.toString());
                        }
                        // Log.e("eeeeeeeeeeeeeeeeeeeeeee", "TO_PROCESS_RX_PACKET TO_PROCESS_RX_PACKET TO_PROCESS_RX_PACKET");
                        processRxPacket(packet);
                        break;

                    case TO_TERMINATE:
                        Log.e( "close", "TO_TERMINATE" );
                        bleService.close();
                        break NETSTRAP_LOOP;
                }
            }
        } catch (InterruptedException e) {
            Log.e(this.getClass().getName(), e.getMessage(), e);
        }
    }

    public void end() {
        addTask(new NetstrapTask(NetstrapState.TO_TERMINATE));
    }

}
