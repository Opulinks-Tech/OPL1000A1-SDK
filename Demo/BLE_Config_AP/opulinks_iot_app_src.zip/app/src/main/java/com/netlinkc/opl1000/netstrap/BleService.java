package com.netlinkc.opl1000.netstrap;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCallback;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.BluetoothLeScanner;
import android.bluetooth.le.ScanCallback;
import android.bluetooth.le.ScanResult;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.ParcelUuid;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;

import com.netlinkc.opl1000.mainapplication.BLEActivity;
import com.netlinkc.opl1000.mainapplication.MainActivity;
import com.netlinkc.opl1000.mainapplication.R;

import java.io.ByteArrayOutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

public class BleService 
{
   public final static int BLE_MTU_DEFAULT = 23;
   public final static int BLE_MTU_EXTENTED = 247;

   //private final static String NETSTRAP_DEVICE_ID = "AA:BB:CC:DD:EE:FF";
   private final static String NETSTRAP_DEVICE_ID = "11:22:AA:AA:AA:BB";

   private final static UUID SERVICE_UUID               = UUID.fromString("0000AAAA-0000-1000-8000-00805F9B34FB");

   private final static UUID CHARACTERISTIC_TX_UUID = UUID.fromString("0000BBB0-0000-1000-8000-00805F9B34FB");

   private final static UUID CHARACTERISTIC_RX_UUID = UUID.fromString("0000BBB1-0000-1000-8000-00805F9B34FB");

   private final static int BLE_STATUS_IDLE = 0;

   private final static int BLE_STATUS_SCANNING = 1;

   private final static int BLE_STATUS_CONNECTING = 2;

   private final static int BLE_STATUS_CONNECTED = 3;

   private Context context;

   public Context MessageContext;

   // public BluetoothAdapter mBluetoothAdapter;

   private BluetoothLeScanner bleScanner;

   private ScanCallback bleScanCallback;

   public List<ScanResult> bleScannedDeviceList = new ArrayList<>();

   private BluetoothDevice bleDevice;

   public BluetoothGatt bleGattClient;

   private BluetoothGattCharacteristic characteristicTx;

   private BluetoothGattCharacteristic characteristicRx;

   private NetstrapService netstrapService;

   public int bleStatus;

   private byte[] characteristicData;

   private int characteristicCursor;

   private int mtu;

   private String  UUIDs, TxPower;

   private boolean IPAddr = false;


   public static String get16BitsUuid(UUID uuid) 
   {
      return String.format("%X", uuid.getMostSignificantBits() >> 32);
   }

   public BleService(Context context)
   {
      this.context = context;
	  
      BluetoothManager bleManager = (BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE);
      bleScanner = bleManager.getAdapter().getBluetoothLeScanner();
   }

   public void setNetstrapService(NetstrapService netstrapService)
   {
      this.netstrapService = netstrapService;
   }

   public boolean ConnectBLE(final String address)
   {
       BluetoothAdapter mBluetoothAdapter = ((BluetoothManager) context.getSystemService(Context.BLUETOOTH_SERVICE)).getAdapter();   // enable bluetooth
       if (mBluetoothAdapter == null || address == null) {
           // Log.w(TAG, "BluetoothAdapter not initialized or unspecified address.");
           return false;
       }

       // Previously connected device.  Try to reconnect.
       /*if (mBluetoothDeviceAddress != null && address.equals(mBluetoothDeviceAddress)
               && mBluetoothGatt != null) {
           Log.d(TAG, "Trying to use an existing mBluetoothGatt for connection.");
           if (mBluetoothGatt.connect()) {
               mConnectionState = STATE_CONNECTING;
               return true;
           } else {
               return false;
           }
       }*/

       final BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
       if (device == null) {
            Log.e("ConnectBLE", "11111111111111 Device not found.  Unable to connect.");
           return false;
       }
       else
       {
           BleService.this.bleDevice = device;
           BleService.this.bleScanner.stopScan(bleScanCallback);
           // LogService.log(" *** Target OPL1000 device is found.");
           Log.e("ConnectBLE", "Target OPL1000 device is found. ==> " + address);
           netstrapService.addTask(new NetstrapTask(NetstrapState.TO_CONNECT_DEVICE));
       }

       return true;
   }

   public void scan()
   {
      Log.e( "scan ==>", "bleDevice.getAddress()" );

      bleScanCallback = new ScanCallback()
	  {
         public void onScanResult( int callbackType, ScanResult result )
		 {
            BluetoothDevice bleDevice = result.getDevice();

             if( !bleScannedDeviceList.contains(result) )   // if( !bleScannedDeviceList.contains(bleDevice.getAddress()) )
			{
			    // Log.e( "11111111111111111", bleDevice.getAddress() );
//                LogService.log("Device Found: [" + bleDevice.getAddress() + "]");
                if( NETSTRAP_DEVICE_ID.equals(bleDevice.getAddress()) )
				{
                    BleService.this.bleDevice = bleDevice;
                    BleService.this.bleScanner.stopScan(this);
                    LogService.log(" *** Target OPL1000 device is found.");
//                    netstrapService.addTask(new NetstrapTask(NetstrapState.TO_CONNECT_DEVICE));
                }

                bleScannedDeviceList.add(result);   // bleScannedDeviceList.add(bleDevice.getAddress());
            }
         }
      };
	
      bleScanner.startScan(bleScanCallback);
      bleStatus = BLE_STATUS_SCANNING;
   }

    public void onLeScan( final BluetoothDevice device, final int rssi, final byte[] scanRecord )
    {
        int startByte = 2;
        boolean patternFound = false;
        // 尋找ibeacon
        // 先依序尋找第2到第8陣列的元素
        while (startByte <= 5) {
            // Identifies an iBeacon
            if (((int) scanRecord[startByte + 2] & 0xff) == 0x02 &&
                    // Identifies correct data length
                    ((int) scanRecord[startByte + 3] & 0xff) == 0x15)
            {

                patternFound = true;
                break;
            }
            startByte++;
        }

        // 如果找到了的话
        //if (patternFound) {
            // 轉換16進制
            byte[] uuidBytes = new byte[16];
            // 來源、起始位置
            System.arraycopy(scanRecord, startByte + 4, uuidBytes, 0, 16);
            String hexString = bytesToHex(uuidBytes);

            // UUID
            String uuid = hexString.substring(0, 8) + "-"
                    + hexString.substring(8, 12) + "-"
                    + hexString.substring(12, 16) + "-"
                    + hexString.substring(16, 20) + "-"
                    + hexString.substring(20, 32);

        UUIDs = uuid;

            // Major
            int major = (scanRecord[startByte + 20] & 0xff) * 0x100
                    + (scanRecord[startByte + 21] & 0xff);

            // Minor
            int minor = (scanRecord[startByte + 22] & 0xff) * 0x100
                    + (scanRecord[startByte + 23] & 0xff);

            String mac = device.getAddress();
            // txPower
            int txPower = (scanRecord[startByte + 24]);
            double distance = calculateAccuracy(txPower,rssi);

            TxPower = Integer.toString(txPower);

            Log.e("qqq", "Name：" + device.getName() + "\nMac：" + mac
                    + " \nUUID：" + uuid + "\nMajor：" + major + "\nMinor："
                    + minor + "\nTxPower：" + txPower + "\nrssi：" + rssi);

            Log.e("aaa","distance："+calculateAccuracy(txPower,rssi));

        /*}
        else
           Log.e("2222222222222222222222", "qweqweqweqweqeqweqweqweqeqe");*/
    }


    public String bytesToHex(byte[] bytes)
    {
        char[] hexArray = "0123456789ABCDEF".toCharArray();

        char[] hexChars = new char[bytes.length * 2];
        for (int j = 0; j < bytes.length; j++) {
            int v = bytes[j] & 0xFF;
            hexChars[j * 2] = hexArray[v >>> 4];
            hexChars[j * 2 + 1] = hexArray[v & 0x0F];
        }
        return new String(hexChars);
    }


    public double calculateAccuracy(int txPower, double rssi)
    {
        if (rssi == 0)
        {
            return -1.0;
        }

        double ratio = rssi * 1.0 / txPower;

        if (ratio < 1.0)
        {
            return Math.pow(ratio, 10);
        }
        else
        {
            double accuracy = (0.89976) * Math.pow(ratio, 7.7095) + 0.111;
            return accuracy;
        }
    }


   String StringdeviceTypeTyString(int paramInt)
   {
      switch(paramInt)
      {
         default:

              return "UNKNOWN";
         case 1:

              return "CLASSIC";
         case 3:

              return "CLASSIC and BLE";
         case 2:
      }

      return "BLE only";
   }

   public void connect()
   {
      bleGattClient = bleDevice.connectGatt(context, false, new BluetoothGattCallback()
	  {
         public void onConnectionStateChange(BluetoothGatt gatt, int status, int newState)
		 {
            switch(newState)
			{
               case BluetoothProfile.STATE_CONNECTED:
			   
                    bleStatus = BLE_STATUS_CONNECTED;

                    Log.e( "connect", "*** OPL1000 device connected.");
                    LogService.log("*** OPL1000 device "+ gatt.getDevice().getAddress()+" connected.");
                    netstrapService.addTask(new NetstrapTask(NetstrapState.TO_EXCHANGE_MTU));
                    break;
               case BluetoothProfile.STATE_DISCONNECTED:

                    Log.e( "connect", "*** OPL1000 device disconnected, status: " + status + ":" + MainActivity.ScanApList + ":" + MainActivity.ConnectApAction + ":" + MainActivity.CurrentBLE.length());
                    LogService.log("*** OPL1000 device disconnected, status: " + status);
                    if( bleStatus == BLE_STATUS_CONNECTING )
					{
                        netstrapService.addTask(new NetstrapTask(NetstrapState.TO_CONNECT_DEVICE));
                    } 
					else
					{
                       bleStatus = BLE_STATUS_IDLE;
                    }

                   if( MainActivity.ScanApList || MainActivity.ConnectApAction || MainActivity.CurrentBLE.length() > 0 )
                   {
                       Intent intent = new Intent("com.netlinkc.opl1000.DisConnectedBLE");

                       MainActivity.bleService.context.sendBroadcast(intent);

                       intent = new Intent("com.netlinkc.opl1000.DisConnectedAp");

                       MainActivity.CurrentBLE = "";
                       MainActivity.CurrentBLEMac = "";
                       MainActivity.ScanApList = false;
                       if( MainActivity.bleService.MessageContext != null )
                           MainActivity.bleService.MessageContext.sendBroadcast(intent);
                   }

                   break;
            }
         }

         public void onReadRemoteRssi(BluetoothGatt gatt, int rssi, int status)
         {
            if( status == BluetoothGatt.GATT_SUCCESS )
                Log.e("BluetoothRssi", String.format("BluetoothGat ReadRssi[%d]", rssi));
         }

         public void onMtuChanged(BluetoothGatt gatt, int mtu, int status)
		 {
            if( status == BluetoothGatt.GATT_SUCCESS )
			{
                BleService.this.mtu = mtu;
                Log.e( "onMtuChanged", "*** The gatt mut has changed, mtu: " + mtu + "  ***");
                LogService.log("*** The gatt mut has changed, mtu: " + mtu + "  ***");
            }
			else
			{
               BleService.this.mtu = BLE_MTU_DEFAULT;
               LogService.log("*** The gatt mut changing failed, status: " + status + "  ***");
               Log.e( "onMtuChanged", "*** The gatt mut changing failed, mtu: " + mtu + "  ***");
            }
			
            netstrapService.addTask(new NetstrapTask(NetstrapState.TO_DISCOVER_SERVICE));
         }


         public void onServicesDiscovered(BluetoothGatt gatt, int status) 
		 {
            LogService.log("*** The gatt service on OPL1000 is discovered.");
            Log.e( "onServicesDiscovered", "*** The gatt service on OPL1000 is discovered.");
            netstrapService.addTask(new NetstrapTask(NetstrapState.TO_READ_CHARACTERISTIC));
         }


         public void onCharacteristicWrite(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic, int status)
		 {
            StringBuilder str = new StringBuilder();
            for( int i = 0; i < characteristic.getValue().length; i++ )
                 str.append(String.format("%02X ", characteristic.getValue()[i]));
			 
            if( !netstrapService.isOtaStarted() )
			{
                LogService.log("*** Tx " + str.toString());
                Log.e( "onCharacteristicWrite", "*** Tx " + str.toString());
            }

            writeBleCharacteristicIfRemained();
         }

         boolean ChkErrorPacket = false;
         public void onCharacteristicChanged(BluetoothGatt gatt, BluetoothGattCharacteristic characteristic)
		 {
		    int             ApConnectStatus = 0;
            StringBuilder   str = new StringBuilder();

            for( int i = 0; i < characteristic.getValue().length; i++ )
                 str.append(String.format("%02X ", characteristic.getValue()[i]));

            if( !netstrapService.isOtaStarted() )
            {
                String Connected = "";
                if( MainActivity.ScanApStatus )
                {
                    if( ChkErrorPacket || characteristic.getValue().length <= 4 )
                    {
                        ChkErrorPacket = false;
                        return;
                    }

                    Connected = str.toString().trim();
                    if( Connected.substring(0, 5).equals("01 10") || Connected.substring(0, 5).equals("00 10") )
                    {
                        Connected = Connected.substring(Connected.length() - 2);

                        if( Connected.equals("00") )
                            ApConnectStatus = 0;
                        else if( Connected.equals("01") )
                                 ApConnectStatus = 1;
                        else
                        {
                            Log.e("onCharacteristicChanged", "error Rx " + str.toString() + ":" + Connected);
                            ChkErrorPacket = true;
                            return;
                        }

                        if( str.toString().equals("01 10 01 00 00 ") )   // 當沒收到 PDU_TYPE_EVT_SCAN_END , Scanning AP End
                        {
                            Intent intent = new Intent("com.netlinkc.opl1000.ScanAPEnd");

                            MainActivity.bleService.MessageContext.sendBroadcast(intent);
                        }

                        // Log.e( "onCharacteristicChanged", "*** Rx " + str.toString() + ":" + Connected );
                    }
                    else
                       return;
                }

                if( MainActivity.ConnectApAction )
                {
                    Intent   intent = new Intent( "com.netlinkc.opl1000.ConnectedApStatus" );
                    String   TmpStr = str.toString();

                    if( TmpStr.equals("02 10 01 00 01 ") || TmpStr.equals("03 10 01 00 01 ") )
                    {
                        IPAddr = false;
                        intent.putExtra("ConnectApStatus", "0");
                    }
                    else
                    {
                       IPAddr = true;
                       intent.putExtra("ConnectApStatus", "1");
                    }
                    Log.e("55555555 = " + IPAddr, "TmpStr = " + TmpStr);

                    if( TmpStr.equals("03 10 01 00 01 ") )
                        intent.putExtra( "ShowMessage", "1" );
                    else
                       intent.putExtra( "ShowMessage", "0" );

                    MainActivity.ConnectApAction = false;
                    MainActivity.bleService.MessageContext.sendBroadcast( intent );
                }

                if( IPAddr )
                {
                    String   TmpStr = str.toString().trim();
                    // Log.e("222222222222 = " + TmpStr.length(), "TmpStr = " + TmpStr);
                    if( TmpStr.substring(0, 5).equals("00 20") )
                    {
                        if( TmpStr.length() > 50 )
                        {
                            int        kk = 0, ipaddress[]={0,0,0,0,0,0,0,0,0,0,0,0};
                            Intent     intent = new Intent( "com.netlinkc.opl1000. " );
                            String     IPAddr, MaskAddr, GatewayAddr, IPStr = TmpStr.substring(TmpStr.length() - 35).trim();
                            String[]   tokens = IPStr.split(" ");


                            for( String token:tokens )
                            {
                                 ipaddress[kk] = Integer.parseInt(token, 16);
                                 kk++;
                            }

                            IPAddr = String.format("%d.%d.%d.%d", ipaddress[0], ipaddress[1], ipaddress[2], ipaddress[3]);
                            MaskAddr = String.format("%d.%d.%d.%d", ipaddress[4], ipaddress[5], ipaddress[6], ipaddress[7]);
                            GatewayAddr = String.format("%d.%d.%d.%d", ipaddress[8], ipaddress[9], ipaddress[10], ipaddress[11]);

                            intent.putExtra( "IPAddr", IPAddr );
                            intent.putExtra( "MaskAddr", MaskAddr );
                            intent.putExtra( "GatewayAddr", GatewayAddr );
                            MainActivity.bleService.MessageContext.sendBroadcast( intent );

                            Log.e("111111111111111111", "IPStr = " + IPAddr );
                            Log.e("111111111111111111", "IPStr = " + MaskAddr );
                            Log.e("111111111111111111", "IPStr = " + GatewayAddr );
                        }
                    }
                }

                Log.e( "onCharacteristicChanged", "*** Rx " + str.toString() + ":" + Connected );

                if( MainActivity.WIFIReset )
                {
                    if( str.toString().equals("08 10 01 00 00 ") )
                    {
                        Log.e( "onCharacteristicChanged" + str.toString()+"aaa", "" + MainActivity.WIFIReset );

                        Intent   intent = new Intent( "com.netlinkc.opl1000.WIFIReset" );

                        MainActivity.WIFIReset = false;
                        MainActivity.bleService.MessageContext.sendBroadcast( intent );
                    }
                }
            }
            /*else
               LogService.log("*** Rx " + str.toString());*/

                // packet processing
            for( NetstrapPacket packet : NetstrapPacket.decodePacket(characteristic.getValue()) )
			{
                 NetstrapTask task = new NetstrapTask( NetstrapState.TO_PROCESS_RX_PACKET );

                 /*if( NetstrapPacket.getAuthModeDescription(packet.getAuthMode()).equals("OPEN") )
                     packet.ApConnectStatus = 1;
                 else*/
                    packet.ApConnectStatus = ApConnectStatus;

                 task.setData("netstrapPacket", packet);
                 netstrapService.addTask(task);
            }
         }
      });
	  
      bleStatus = BLE_STATUS_CONNECTING;
   }

   public void exchangeMtu()
   {
      bleGattClient.requestConnectionPriority( BluetoothGatt.CONNECTION_PRIORITY_HIGH );
      bleGattClient.requestMtu( BLE_MTU_EXTENTED );
   }

   public void discover()
   {
      bleGattClient.discoverServices();
   }

   public void readCharacteristic()
   {
      List<BluetoothGattService> serviceList = bleGattClient.getServices();

      for( BluetoothGattService s : serviceList )
	  {
           List<BluetoothGattCharacteristic> charList = s.getCharacteristics();
           // LogService.log("\t\t\tService:\t\t\t\t\t\t\t\t 0x" + String.format("%02X", s.getInstanceId()) + ", 0x" + get16BitsUuid(s.getUuid()));

           Log.e( "readCharacteristic", "\t\t\tService:\t\t\t\t\t\t\t\t 0x" + String.format("%02X", s.getInstanceId()) + ", 0x" + get16BitsUuid(s.getUuid()) );

           for( BluetoothGattCharacteristic c : charList )
		   {
                LogService.log("  \t\t\tCharacteristic:\t 0x" + String.format("%02X", c.getInstanceId()) + ", 0x" + get16BitsUuid(c.getUuid()) + ", 0x" + String.format("%02X", c.getProperties()));

                if( CHARACTERISTIC_TX_UUID.equals(c.getUuid()) )
				{
                    characteristicTx = c;
                } 
				else if( CHARACTERISTIC_RX_UUID.equals(c.getUuid()) )
				{
                         characteristicRx = c;
                         bleGattClient.setCharacteristicNotification(c, true);
                }
           }
      }

      if( characteristicTx != null && characteristicRx != null )
	  {
          Log.e("readCharacteristic", "*** The Tx/Rx service is ready.");
          LogService.log("*** The Tx/Rx service is ready.");
          netstrapService.addTask(new NetstrapTask(NetstrapState.TO_READ_FIRMWARE_VERSION));
      } 
	  else
	  {
         Log.e("readCharacteristic", "*** The Tx/Rx characteristic disappear.");
         LogService.log("*** The Tx/Rx characteristic disappear.");
      }
  }

  public void send(byte[] data)
  {
     characteristicData = data;
     characteristicCursor = 0;
     writeBleCharacteristicIfRemained();
  }

  private void sendCompletedEvent()
  {
     if( netstrapService.isOtaStarted() )
	 {
         netstrapService.addTask(new NetstrapTask(NetstrapState.OTA_SEND));
     }
  }

  private void writeBleCharacteristicIfRemained()
  {
     if( characteristicTx == null )
     {
         Log.e("writeBleCharacteristicIfRemained", "characteristicTx = null");
         return;
     }

     synchronized( BleService.class )
	 {
        if( characteristicData != null )
		{
            int availableTransmitLength = BleService.this.mtu - 3;
            int lastCursor = characteristicCursor;
            int fragLength = (characteristicCursor + availableTransmitLength <= characteristicData.length) ? availableTransmitLength : (characteristicData.length - characteristicCursor);

            ByteArrayOutputStream out = new ByteArrayOutputStream();

            out.write(characteristicData, lastCursor, fragLength);
            characteristicTx.setValue(out.toByteArray());
            characteristicTx.setWriteType(BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE);
            bleGattClient.writeCharacteristic(characteristicTx);

            characteristicCursor += fragLength;
            if( characteristicCursor == characteristicData.length )
			{
                characteristicData = null;
                characteristicCursor = 0;
            }
        }
		else 
		{
           sendCompletedEvent();
        }
    }
  }

  public void close() 
  {
     switch( bleStatus )
	 {
        case BLE_STATUS_SCANNING:
             Log.e( "close", "BLE_STATUS_SCANNING" );
             bleScanner.stopScan(bleScanCallback);
             break;

        case BLE_STATUS_CONNECTING:
        case BLE_STATUS_CONNECTED:
             Log.e( "close ---------------------------------", "BLE_STATUS_CONNECTED" );
             bleGattClient.close();
             break;
     }
  }

    public void disconnect() {
        if(bleGattClient!=null) {
            bleGattClient.disconnect();
            bleGattClient.close();
        }
    }
}
